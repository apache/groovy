
            import groovy.beans.Bindable
            import java.beans.PropertyChangeEvent
            import java.beans.PropertyChangeListener

            @Bindable
            class BindableTestBeanChild extends BindableTestBeanParent {
                String prop2
                BindableTestBeanChild() {
                    super()
                }
            }

            @Bindable
            class BindableTestBeanParent implements PropertyChangeListener {
                String prop1
                BindableTestBeanParent() {
                    addPropertyChangeListener(this)
                }

                void propertyChange(PropertyChangeEvent event) {}
            }

            new BindableTestBeanChild()
        

// src/test/groovy/beans/BindableTest.groovy
