import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy

            @Retention(RetentionPolicy.RUNTIME)
            @interface Service {}
            @Retention(RetentionPolicy.RUNTIME)
            @interface Transactional {}

            // tag::transactionalservice_class[]
            @Service
            @Transactional
            class MyTransactionalService {}
            // end::transactionalservice_class[]

            MyTransactionalService
        

// src/spec/test/ClassTest.groovy
