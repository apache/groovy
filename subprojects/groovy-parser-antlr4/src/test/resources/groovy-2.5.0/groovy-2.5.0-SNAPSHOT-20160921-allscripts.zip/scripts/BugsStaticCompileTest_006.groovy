int squarePlusOne(int num) {
                num ** num + 1
            }
            assert squarePlusOne(2) == 5
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
