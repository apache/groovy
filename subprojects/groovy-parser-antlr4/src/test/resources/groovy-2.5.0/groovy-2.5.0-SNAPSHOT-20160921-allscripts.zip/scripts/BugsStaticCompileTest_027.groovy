
                int x = 0
                --x
                --x
                assert --x == -3
                assert x == -3
            

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
