
            class X {
                def 'foo!bar'() {
                    return {}
                }
            }
            def str = new X().'foo!bar'().getClass().getName()
            assert str == 'X$_foo_bar_closure1'
        

// src/test/org/codehaus/groovy/ClosureAndInnerClassNodeStructureTest.groovy
