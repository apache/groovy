
            List<Integer> list = [1, 2, 3]
            List<Integer> immutableList = [1, 2, 3].asImmutable()
            Map<String, Integer> map = [foo: 123, bar: 456]
            Map<String, Integer> immutableMap = [foo: 123, bar: 456].asImmutable()
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
