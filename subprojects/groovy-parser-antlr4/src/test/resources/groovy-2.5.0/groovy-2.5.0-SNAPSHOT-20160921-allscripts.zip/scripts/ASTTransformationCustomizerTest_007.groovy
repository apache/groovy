
            Integer(11) + Long(31)
        

// src/test/org/codehaus/groovy/control/customizers/ASTTransformationCustomizerTest.groovy
