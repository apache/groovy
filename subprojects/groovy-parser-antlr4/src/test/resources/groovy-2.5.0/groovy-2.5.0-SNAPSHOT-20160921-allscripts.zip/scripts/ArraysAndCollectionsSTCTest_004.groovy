
            String[] arr = ['1','2','3']
            for (i in arr) { }
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
