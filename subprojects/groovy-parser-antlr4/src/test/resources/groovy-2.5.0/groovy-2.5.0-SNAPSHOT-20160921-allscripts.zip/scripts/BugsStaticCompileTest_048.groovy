
            def list = 'a,b,c'.split(/,/)*.trim()
            assert list == ['a','b','c']
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
