
              @groovy.transform.Canonical class Foo {
                  def x
                  def y = 10
              }
              new Foo()
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
