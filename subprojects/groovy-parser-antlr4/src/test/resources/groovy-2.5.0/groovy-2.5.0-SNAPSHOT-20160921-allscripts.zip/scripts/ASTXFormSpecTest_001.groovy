package gep
            // tag::withlogging_example[]
            @WithLogging
            def greet() {
                println "Hello World"
            }

            greet()
            // end::withlogging_example[]
        

// src/spec/test/metaprogramming/ASTXFormSpecTest.groovy
