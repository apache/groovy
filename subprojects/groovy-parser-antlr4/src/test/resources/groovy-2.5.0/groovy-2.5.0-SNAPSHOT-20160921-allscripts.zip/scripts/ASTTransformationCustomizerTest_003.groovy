
            class MyClass {
                int distance
                MyClass() {}
            }
            new MyClass()
        

// src/test/org/codehaus/groovy/control/customizers/ASTTransformationCustomizerTest.groovy
