
            interface A { void m() }
            interface B { void m() }
            class C implements A,B {
                void m() {}
            }
            class D {
             D(C c) {
               c.m()
             }
            }

            new D(new C())
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
