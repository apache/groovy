
            import groovy.transform.builder.*
            import groovy.transform.*

            @Canonical
            @Builder(builderStrategy=InitializerStrategy, useSetters=true)
            class Person {
                String name
                void setName(String name) { this.name = name?.toUpperCase() }
            }

            @CompileStatic
            def make() {
                assert new Person(Person.createInitializer().name("John")).toString() == 'Person(JOHN)'
            }
            make()
        

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
