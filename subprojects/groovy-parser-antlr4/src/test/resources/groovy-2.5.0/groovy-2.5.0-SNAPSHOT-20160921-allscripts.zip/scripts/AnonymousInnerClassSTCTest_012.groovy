
            Comparator<Integer> comp = new Comparator<Integer>(){
                @Override
                int compare(Integer o1, Integer o2) {
                    return 0
                }
            }
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
