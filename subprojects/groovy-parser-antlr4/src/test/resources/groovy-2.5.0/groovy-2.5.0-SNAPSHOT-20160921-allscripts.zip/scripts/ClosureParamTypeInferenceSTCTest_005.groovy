
            assert [1234, 3.14].collect { it.intValue() } == [1234,3]
        

// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
