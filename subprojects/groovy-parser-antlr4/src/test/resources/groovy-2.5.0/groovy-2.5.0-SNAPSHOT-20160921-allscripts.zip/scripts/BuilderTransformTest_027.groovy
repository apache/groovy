
            import groovy.transform.builder.*

            @Builder(builderStrategy = InitializerStrategy, allNames = true)
            class HasInternalProperty {
                String $internal
            }

            def initializer = HasInternalProperty.createInitializer()
            assert new HasInternalProperty(initializer.$internal("foo")).$internal == "foo"
         

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
