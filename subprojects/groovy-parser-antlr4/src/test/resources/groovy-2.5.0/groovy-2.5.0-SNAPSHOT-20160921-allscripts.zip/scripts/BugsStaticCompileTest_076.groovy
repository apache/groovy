import java.util.concurrent.Callable

    String text(Class clazz) {
        new Callable<String>() {
            String call() throws Exception {
                new Callable<String>() {
                    String call() throws Exception {
                        clazz.getName()
                    }
                }.call()
            }
        }.call()
    }

    assert text(String) == 'java.lang.String'
    

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
