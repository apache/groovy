
            import groovy.transform.Canonical
            @Canonical class Foo {
                String x, y
            }
            [new Foo(x:'x', y:'y'),
             new Foo('x', 'y')]
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
