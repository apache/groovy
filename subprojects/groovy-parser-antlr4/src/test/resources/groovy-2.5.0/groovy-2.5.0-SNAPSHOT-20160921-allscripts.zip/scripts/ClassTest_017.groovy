
            // tag::properties_meta[]
            class Person {
                String name
                int age
            }
            def p = new Person()
            assert p.properties.keySet().containsAll(['name','age'])
            // end::properties_meta[]

        

// src/spec/test/ClassTest.groovy
