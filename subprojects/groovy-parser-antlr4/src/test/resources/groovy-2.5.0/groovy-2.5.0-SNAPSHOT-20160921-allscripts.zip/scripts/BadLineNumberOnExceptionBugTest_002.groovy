
            def foo() {
                integer.metaClass = null // line 3
                integer.metaClass = null
                integer.metaClass = null
                integer.metaClass = null
            }
            
            try {
                foo()

                assert false
            } catch (MissingPropertyException e) {
                def scriptTraceElement = e.stackTrace.find { it.declaringClass.startsWith(GroovyTestCase.TEST_SCRIPT_NAME_PREFIX) }
                assert 3 == scriptTraceElement.lineNumber
            }
        

// src/test/groovy/bugs/BadLineNumberOnExceptionBugTest.groovy
