
            class Foo {
                boolean hasSideEffect = false
                int x() { hasSideEffect=true; 333 }
            }
            Foo foo = new Foo()
            if (foo.x()==null) {
                println 'ok'
            }
            assert foo.hasSideEffect
         

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
