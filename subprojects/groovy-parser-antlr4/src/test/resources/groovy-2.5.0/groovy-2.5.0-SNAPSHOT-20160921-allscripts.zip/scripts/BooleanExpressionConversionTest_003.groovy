
            boolean foo(float i){
                if (i) return true
                return false
            }
            assert !foo(0)
            assert foo(1)
            assert foo(256)
        

// src/test/gls/types/BooleanExpressionConversionTest.groovy
