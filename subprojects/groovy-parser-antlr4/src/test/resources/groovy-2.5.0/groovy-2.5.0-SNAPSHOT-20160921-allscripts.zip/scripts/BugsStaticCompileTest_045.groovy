
                boolean x = false
                def cl = {
                    if (!x) {
                        assert true
                    } else {
                        assert false
                    }
                }
                cl()
            

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
