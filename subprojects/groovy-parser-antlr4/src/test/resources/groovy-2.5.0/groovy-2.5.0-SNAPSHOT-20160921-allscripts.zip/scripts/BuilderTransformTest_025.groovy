
            import groovy.transform.builder.*

            class HasInternalProperty {
                String $internal
            }

            @Builder(builderStrategy = ExternalStrategy, forClass = HasInternalProperty, allNames = true)
            class HasInternalPropertyBuilder { }

            assert new HasInternalPropertyBuilder().$internal("foo").build().$internal == "foo"
         

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
