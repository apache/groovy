
                @groovy.transform.Canonical class Simple { }
                new Simple(missing:'Name')
            

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
