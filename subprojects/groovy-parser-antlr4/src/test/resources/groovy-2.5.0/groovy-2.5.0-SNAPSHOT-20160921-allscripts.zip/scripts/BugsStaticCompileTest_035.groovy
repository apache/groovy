
                long incInt(long n) {
                    def result = n
                    ++result
                    result++
                    return result
                }
                assert  incInt(5) == 7

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
