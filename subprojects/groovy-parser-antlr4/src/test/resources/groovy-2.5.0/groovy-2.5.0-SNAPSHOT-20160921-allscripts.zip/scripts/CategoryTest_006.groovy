
            class Cat {
              public static findAll(Integer x, Closure cl) {1}   
            }

             def foo(x) {
                 x.findAll {}
             }
             
             use (Cat) {
                 assert foo(1) == 1
                 assert foo(1) == 1
                 assert foo(1) == 1
                 assert foo(null) == []
                 assert foo(1) == 1
                 assert foo(1) == 1
                 assert foo(1) == 1
             }
        

// src/test/groovy/CategoryTest.groovy
