
            class DeclaredBaseScript extends Script {
                boolean iBeenRun
                def run() { iBeenRun = true }
            }

            @groovy.transform.BaseScript DeclaredBaseScript baseScript

            assert !iBeenRun

            super.run()

            assert iBeenRun

            iBeenRun
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
