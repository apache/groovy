
def c = { x ->
    def y = 123
    def c1 = { 
        assert x != null , "Could not find a value for x"
        assert y == 123 , "Could not find a value for y"
        println x[0]
    }

    c1()
} 

c([1]) 


// src/test/groovy/bugs/ClosureParameterPassingBug.groovy
