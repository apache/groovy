
// tag::example_autoext_excludes[]
import groovy.transform.AutoExternalize

@AutoExternalize(excludes='price')
class Book {
    String isbn
    String title
    float price
}
// end::example_autoext_excludes[]

def book = new Book(isbn: 'xxx', title:'Auto externalization for dummies', price: 15)
def str = ''
ObjectOutput o = {
   str = "$str$it/"
} as ObjectOutput
book.writeExternal(o)
assert str == "xxx/Auto externalization for dummies/"
int idx = 0
ObjectInput i = {
    switch (idx++) {
        case 0:
            'xxx'
            break
        case 1:
            'Auto externalization for dummies'
            break
        case 2:
            1.5f
            break
    }
} as ObjectInput
book = new Book()
book.readExternal(i)
assert book.isbn == 'xxx'
assert book.title == 'Auto externalization for dummies'
assert book.price == 0 // because price is excluded


// src/spec/test/CloningASTTransformsTest.groovy
