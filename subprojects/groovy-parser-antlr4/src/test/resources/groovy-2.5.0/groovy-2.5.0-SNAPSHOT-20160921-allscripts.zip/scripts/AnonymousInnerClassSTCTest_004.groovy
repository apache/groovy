
            abstract class Foo { abstract String item() }
            Foo f = new Foo() {
                String item() { 'ok' }
            }
            assert f.item() == 'ok'
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
