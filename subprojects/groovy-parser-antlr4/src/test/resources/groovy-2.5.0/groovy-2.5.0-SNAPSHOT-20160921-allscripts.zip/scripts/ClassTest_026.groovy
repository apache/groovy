
            @interface SomeAnnotation {
                int value() default 0
            }

            // tag::apply_annotation_1[]
            @SomeAnnotation                 // <1>
            void someMethod() {
                // ...
            }

            @SomeAnnotation                 // <2>
            class SomeClass {}

            @SomeAnnotation String var      // <3>

            // end::apply_annotation_1[]
            someMethod()
        

// src/spec/test/ClassTest.groovy
