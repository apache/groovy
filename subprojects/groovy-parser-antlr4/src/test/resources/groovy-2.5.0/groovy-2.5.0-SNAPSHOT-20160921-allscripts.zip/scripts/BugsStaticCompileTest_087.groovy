
            class Foo {
                long rankOrderingOrId
                void setRankOrderingOrId(long rankOrderingOrId) {
                    this.rankOrderingOrId = rankOrderingOrId < 0 ? -1 : rankOrderingOrId
                }
            }
            def f = new Foo()
            f.setRankOrderingOrId(1L)
            assert f.getRankOrderingOrId() == 1L
            assert f.rankOrderingOrId == 1L
            f.rankOrderingOrId = 2L
            assert f.getRankOrderingOrId() == 2L
            assert f.rankOrderingOrId == 2L
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
