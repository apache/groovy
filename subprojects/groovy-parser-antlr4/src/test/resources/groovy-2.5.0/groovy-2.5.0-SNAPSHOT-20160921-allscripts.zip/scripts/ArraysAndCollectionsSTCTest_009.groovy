
            List<Integer> a = [1, 3, 5]

            @ASTTest(phase = INSTRUCTION_SELECTION, value = {
                def type = node.rightExpression.getNodeMetaData(INFERRED_TYPE)
                assert type == make(List)
                assert type.genericsTypes.length == 1
                assert type.genericsTypes[0].type == Integer_TYPE
            })
            List<Integer> b = a[1..2]

            List<Integer> c = (List<Integer>)a[1..2]
         

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
