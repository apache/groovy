
            class A {
                void ifCondition(Object x, Object y) {
                    if (x?.is(y))
                        return
                }

                void ternaryCondition(Object x, Object y) {
                    x?.is(y) ? 'foo' : 'bar'
                }
            }
            new A()
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
