
                import groovy.beans.Bindable

                class BindableTestBean11  {
                  @Bindable final String testField
                }
                1+1
            

// src/test/groovy/beans/BindableTest.groovy
