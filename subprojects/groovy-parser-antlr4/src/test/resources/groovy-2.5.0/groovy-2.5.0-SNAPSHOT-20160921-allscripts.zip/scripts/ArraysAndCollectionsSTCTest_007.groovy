
        List<String> foos = ['aa','bb','cc']
        foos[0].substring(1)
        def bars = foos[0..1]
        println bars[0].substring(1)
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
