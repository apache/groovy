
            boolean isFoo() { true }
            assert foo
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
