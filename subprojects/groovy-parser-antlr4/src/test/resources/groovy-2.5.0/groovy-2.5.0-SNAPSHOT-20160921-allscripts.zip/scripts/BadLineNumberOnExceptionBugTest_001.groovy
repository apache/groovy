
            class Foo {
                boolean hello() { true }
            }

            try {
                foo = new Foo()

                if(foo.hello()()) { // line 9
                    println "do"
                    println "do"
                    println "do"
                    println "do"
                }

                assert false
            } catch (MissingMethodException e) {
                def scriptTraceElement = e.stackTrace.find { it.declaringClass.startsWith(GroovyTestCase.TEST_SCRIPT_NAME_PREFIX) }
                assert 9 == scriptTraceElement.lineNumber
            }
        

// src/test/groovy/bugs/BadLineNumberOnExceptionBugTest.groovy
