
            boolean foo(char i){
                if (i) return true
                return false
            }
            assert !foo((char)0)
            assert foo((char)1)
            assert foo((char)256)
        

// src/test/gls/types/BooleanExpressionConversionTest.groovy
