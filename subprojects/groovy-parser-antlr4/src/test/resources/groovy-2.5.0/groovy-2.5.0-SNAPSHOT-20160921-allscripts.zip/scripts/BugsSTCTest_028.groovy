
            Set foo(List<Map.Entry> set) {
                set.collect { Map.Entry entry -> entry.key }.toSet()
            }
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
