
            Serializable s = new Serializable() { List things = [] }
            assert s.things.size() == 0
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
