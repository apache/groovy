
                class BindableTestBean5 {
                     @groovy.beans.Bindable static String name
                }
            

// src/test/groovy/beans/BindableTest.groovy
