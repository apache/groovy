
// tag::example_autoclone_excludes[]
import groovy.transform.AutoClone
import groovy.transform.AutoCloneStyle

@AutoClone(style=AutoCloneStyle.SIMPLE,excludes='authors')
class Book {
    String isbn
    String title
    List authors
    Date publicationDate
}
// end::example_autoclone_excludes[]
def book = new Book(isbn: 'aaa', title: 'The Definitive Guide to cloning', authors:['Dolly'], publicationDate: new Date())
def clone = book.clone()
assert clone.isbn==book.isbn
assert clone.title==book.title
assert clone.authors == null // because excluded
assert clone.publicationDate==book.publicationDate


// src/spec/test/CloningASTTransformsTest.groovy
