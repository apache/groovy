
            // tag::property_access[]
            class Person {
                String name
                void name(String name) {
                    this.name = "Wonder$name"       // <1>
                }
                String wonder() {
                    this.name                       // <2>
                }
            }
            def p = new Person()
            p.name = 'Marge'                        // <3>
            assert p.name == 'Marge'                // <4>
            p.name('Marge')                         // <5>
            assert p.wonder() == 'WonderMarge'      // <6>
            // end::property_access[]
        

// src/spec/test/ClassTest.groovy
