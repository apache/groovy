
// tag::example_autoext_includeFields[]
import groovy.transform.AutoExternalize

@AutoExternalize(includeFields=true)
class Book {
    String isbn
    String title
    protected float price
}
// end::example_autoext_includeFields[]

def book = new Book(isbn: 'xxx', title:'Auto externalization for dummies', price: 15)
def str = ''
ObjectOutput o = {
   str = "$str$it/"
} as ObjectOutput
book.writeExternal(o)
assert str == "xxx/Auto externalization for dummies/15.0/"
int idx = 0
ObjectInput i = {
    switch (idx++) {
        case 0:
            'xxx'
            break
        case 1:
            'Auto externalization for dummies'
            break
        case 2:
            1.5f
            break
    }
} as ObjectInput
book = new Book()
book.readExternal(i)
assert book.isbn == 'xxx'
assert book.title == 'Auto externalization for dummies'
assert book.price == 1.5f


// src/spec/test/CloningASTTransformsTest.groovy
