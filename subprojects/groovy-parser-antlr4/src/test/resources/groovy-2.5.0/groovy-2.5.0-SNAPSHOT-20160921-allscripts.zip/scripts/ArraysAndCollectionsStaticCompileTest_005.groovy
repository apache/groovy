
            Map<String, Object> props(Object p) {
                Map<String, Object> props = [:]

                for(String property in p.properties.keySet()){
                    props[property] = 'TEST'
                    // I need to use calling put directy to make it work
                    // props.put property, 'TEST'
                }
                props
            }
            def map = props('SOME RANDOM STRING')
            assert map['class'] == 'TEST'
            assert map['bytes'] == 'TEST'
        

// src/test/org/codehaus/groovy/classgen/asm/sc/ArraysAndCollectionsStaticCompileTest.groovy
