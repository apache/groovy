import java.util.concurrent.TimeoutException

boolean interrupted = false
try {
    100.times {
        Thread.sleep(100)
    }
} catch (TimeoutException e) {
    interrupted = true
}

interrupted

// src/test/org/codehaus/groovy/control/customizers/ASTTransformationCustomizerTest.groovy
