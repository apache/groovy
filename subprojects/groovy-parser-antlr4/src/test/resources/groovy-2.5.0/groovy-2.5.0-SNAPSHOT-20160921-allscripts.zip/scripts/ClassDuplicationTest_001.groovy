
            class A {}
            def foo(A a) {}
            return this
        

// src/test/gls/invocation/ClassDuplicationTest.groovy
