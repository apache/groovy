import groovy.transform.stc.ClosureParams
            import groovy.transform.stc.FirstParam
            public <T> T foo(T arg, @ClosureParams(FirstParam) Closure c) { c.call(arg) }
            assert foo('a') { it.toUpperCase() } == 'A'


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
