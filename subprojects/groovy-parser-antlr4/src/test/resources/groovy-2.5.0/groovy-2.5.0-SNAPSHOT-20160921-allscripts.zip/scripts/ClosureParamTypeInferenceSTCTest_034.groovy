import groovy.transform.stc.FromString
import groovy.transform.stc.ClosureParams

    class Foo<T> {
        public void foo(@ClosureParams(value=FromString,options="java.util.List<T>") Closure cl) { cl.call(['hey','ya']) }
    }
    def foo = new Foo<String>()

    foo.foo { List<String> str -> str.each { println it.toUpperCase() } }


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
