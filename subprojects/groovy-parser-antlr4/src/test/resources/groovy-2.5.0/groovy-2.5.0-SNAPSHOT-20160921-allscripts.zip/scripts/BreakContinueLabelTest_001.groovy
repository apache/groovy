
            def visited = []
            label1:
            label2:
            label3:
            for (int i = 0; i < 9; i++) {
              visited << i
              if (i == 1) continue label1
              visited << 10 + i
              if (i == 3) continue label2
              visited << 100 + i
              if (i == 5) break label3
            }
            assert visited == [0, 10, 100, 1, 2, 12, 102, 3, 13, 4, 14, 104, 5, 15, 105]
        

// src/test/groovy/BreakContinueLabelTest.groovy
