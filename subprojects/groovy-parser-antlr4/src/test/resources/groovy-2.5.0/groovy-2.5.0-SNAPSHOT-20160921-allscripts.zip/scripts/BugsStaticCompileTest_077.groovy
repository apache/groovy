import org.codehaus.groovy.ast.expr.MethodCallExpression

class GrailsHomeWorkspaceReader {
    @ASTTest(phase=INSTRUCTION_SELECTION,value={
        def defaultValue = node.parameters[0].initialExpression
        assert defaultValue instanceof MethodCallExpression
        def target = defaultValue.getNodeMetaData(DIRECT_METHOD_CALL_TARGET)
        assert target != null
    })
    GrailsHomeWorkspaceReader(String grailsHome = System.getProperty('grails.home')) {
    }
}
new GrailsHomeWorkspaceReader()


// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
