
            def map = new LinkedHashMap([a:1,b:2])
            @ASTTest(phase=INSTRUCTION_SELECTION, value={
                def ift = node.getNodeMetaData(INFERRED_TYPE)
                assert ift == make(Set)
                assert ift.isUsingGenerics()
                assert ift.genericsTypes[0].name=='K'
            })
            def set = map.keySet()
            def key = set[0]
            assert key=='a'
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
