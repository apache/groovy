
                void foo() {
                boolean idx = false
                def cl = { idx }
                }
            

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
