
            String[] strings = ['a','b','c']
            String str = strings[0]
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
