
            ['a','b'].collect { it -> it.toUpperCase() }
        

// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
