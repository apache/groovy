import org.codehaus.groovy.classgen.asm.sc.Groovy6924Support
            class Test {
                static void foo() {
                    Groovy6924Support bean = new Groovy6924Support()
                    bean.with {
                        foo = 'foo'
                        bar = 'bar'
                    }
                    String val = "$bean.foo and $bean.bar"
                    assert val == 'foo and bar'
                }
            }
            Test.foo()
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
