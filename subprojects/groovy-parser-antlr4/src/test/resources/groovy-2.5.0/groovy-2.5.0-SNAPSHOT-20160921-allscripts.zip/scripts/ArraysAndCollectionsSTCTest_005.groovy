
            String[] arr = ['1','2','3']
            for (String i : arr) { }
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
