
            import org.codehaus.groovy.transform.Shopper
            def p1 = new Shopper('John', [['bread', 'milk'], ['bacon', 'eggs']])
            def p2 = p1.clone()
            p2.shoppingHistory[0][1] = 'jam'
            assert p1.shoppingHistory[0] == ['bread', 'milk']
            assert p2.shoppingHistory[0] == ['bread', 'jam']
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
