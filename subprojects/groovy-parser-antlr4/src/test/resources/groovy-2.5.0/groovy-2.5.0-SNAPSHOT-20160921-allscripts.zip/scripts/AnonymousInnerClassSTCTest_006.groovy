abstract class Foo { abstract String item() }
            boolean valid(Foo foo) {
                foo.item() == 'ok'
            }
            def f = new Foo() {
                String item() { 'ok' }
            }
            assert valid(f)
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
