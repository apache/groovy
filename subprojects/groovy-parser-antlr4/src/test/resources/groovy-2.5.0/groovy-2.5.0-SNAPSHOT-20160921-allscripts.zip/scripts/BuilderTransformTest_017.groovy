
            import groovy.transform.builder.*
            import groovy.transform.*

            class Mamal {
                int age
            }
            class Person extends Mamal {
                String firstName
                String lastName
            }

            @Builder(builderStrategy=ExternalStrategy, forClass=Person, includeSuperProperties=true)
            class PersonBuilder { }

            @CompileStatic
            def parentBuilder() {
                Person person = new PersonBuilder().age(21).firstName("Robert").lastName("Lewandowski").build()
                assert person.firstName == "Robert"
                assert person.lastName == "Lewandowski"
                assert person.age == 21
            }
            parentBuilder()
        

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
