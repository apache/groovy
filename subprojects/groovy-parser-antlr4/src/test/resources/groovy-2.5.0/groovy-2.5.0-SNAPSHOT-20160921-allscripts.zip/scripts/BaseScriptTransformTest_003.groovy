
            abstract class DeclaredBaseScript extends Script {
                int meaningOfLife = 42
            }
        
            @groovy.transform.BaseScript DeclaredBaseScript baseScript

            assert meaningOfLife == 42
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
