
                import groovy.beans.Bindable

                class BindableTestBean6 extends javax.swing.JPanel {
                    @Bindable String testField
                }

                sb = new BindableTestBean6()
                sb.testField = "bar"
                changed = false
                sb.propertyChange = {changed = true}
                sb.testField = "foo"
                assert changed
            

// subprojects/groovy-swing/src/test/groovy/groovy/beans/BindableSwingTest.groovy
