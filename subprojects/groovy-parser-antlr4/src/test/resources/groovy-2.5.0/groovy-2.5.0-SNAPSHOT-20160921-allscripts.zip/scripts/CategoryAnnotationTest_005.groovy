
            @Category(Guy)
            class Filtering {
                List process() {
                    this.messages.findAll{it.name != this.getName()}
                }
            }
            
            interface Guy {
                String getName()
                List getMessages()
            }
            
            class MyGuyver implements Guy {
                List messages
                String name
            }
            
            def onetest = new MyGuyver(
                    name: 'coucou',
                    messages : [['name':'coucou'], ['name':'test'], ['name':'salut']])
            
            Guy.mixin   Filtering
            
            assert onetest.process() == onetest.messages.findAll{it.name != onetest.getName()}        
        

// src/test/groovy/lang/CategoryAnnotationTest.groovy
