
            import groovy.transform.builder.*
            import groovy.transform.*

            @Builder
            class Mamal {
                int age
            }
            @Builder(includeSuperProperties=true)
            class Person extends Mamal {
                String firstName
                String lastName
            }

            @CompileStatic
            def parentBuilder() {
                def builder = Person.builder()
                Person person = builder.age(21).firstName("Robert").lastName("Lewandowski").build()
                assert person.firstName == "Robert"
                assert person.lastName == "Lewandowski"
                assert person.age == 21
            }
            parentBuilder()
         

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
