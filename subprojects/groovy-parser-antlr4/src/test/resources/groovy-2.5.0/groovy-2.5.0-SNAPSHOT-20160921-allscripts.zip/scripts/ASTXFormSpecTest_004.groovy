
            // tag::withlogging_example_global[]
            def greet() {
                println "Hello World"
            }

            greet()
            // end::withlogging_example_global[]
        

// src/spec/test/metaprogramming/ASTXFormSpecTest.groovy
