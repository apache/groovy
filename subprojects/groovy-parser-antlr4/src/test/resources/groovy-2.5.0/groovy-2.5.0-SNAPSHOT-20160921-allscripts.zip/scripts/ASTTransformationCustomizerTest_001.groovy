
            class MyClass {}
            new MyClass()
        

// src/test/org/codehaus/groovy/control/customizers/ASTTransformationCustomizerTest.groovy
