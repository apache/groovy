
            import groovy.transform.*

            @ToString @TupleConstructor
            class Foo2 {
                String bar, baz
                void setBar(String bar) {
                    this.bar = bar.toUpperCase()
                }
            }

            assert new Foo2(bar: 'cat', baz: 'dog').toString() == 'Foo2(CAT, dog)'
            assert new Foo2('cat', 'dog').toString() == 'Foo2(cat, dog)'
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
