
            interface A { void m() }
            interface B { void m() }
            interface C extends A, B {}

            class D {
             D(C c) {
               c.m()
             }
            }
            class CImpl implements C {
                void m() { }
            }

            new D(new CImpl())
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
