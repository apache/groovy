
            @groovy.transform.Canonical class This { String value }
            @groovy.transform.Canonical class That { String value }
            class Other { }

            assert new This('foo') == new This("foo")
            assert new This('f${"o"}o') == new This("foo")

            assert new This('foo') != new This("bar")
            assert new This('foo') != new That("foo")
            assert new This('foo') != new Other()
            assert new Other() != new This("foo")
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
