
            class X {
                static class Y {
                    def foo() {
                        def cl = {return{}}
                        def cl2 = cl()
                        [cl.getClass().getSimpleName(), cl2.getClass().getSimpleName()]
                    }
                }
            }
            def simpleNames = new X.Y().foo()
            assert simpleNames == ['_foo_closure1', '_closure2']
        

// src/test/org/codehaus/groovy/ClosureAndInnerClassNodeStructureTest.groovy
