
            def map = [:]
            map['a'] = 1
            map.b = 2
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
