import java.lang.annotation.Retention
import java.lang.annotation.RetentionPolicy

            @Retention(RetentionPolicy.RUNTIME)
            @interface Service {}
            @Retention(RetentionPolicy.RUNTIME)
            @interface Transactional {}

            // tag::metaann_ts[]
            import groovy.transform.AnnotationCollector

            @Service                                        // <1>
            @Transactional                                  // <2>
            @AnnotationCollector                            // <3>
            @interface TransactionalService {
            }
            // end::metaann_ts[]

            // tag::transactionalservice_class2[]
            @TransactionalService                           // <1>
            class MyTransactionalService {}
            // end::transactionalservice_class2[]

            // tag::annotations_expanded[]
            def annotations = MyTransactionalService.annotations*.annotationType()
            assert (Service in annotations)
            assert (Transactional in annotations)
            // end::annotations_expanded[]
        

// src/spec/test/ClassTest.groovy
