
            int countIt(Iterable<Integer> list) {
                int count = 0
                for (Integer obj : list) {count ++}
                return count
            }
            countIt([1,2,3])==3
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
