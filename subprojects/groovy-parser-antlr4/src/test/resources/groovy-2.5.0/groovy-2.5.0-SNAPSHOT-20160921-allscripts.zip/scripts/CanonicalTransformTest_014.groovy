
            @groovy.transform.Canonical class Foo {
                String a
                int b
                char c
                short d
                long e
                byte f
                double h
                float i
                boolean j
            }
            
            new Foo("foo")
            new Foo("foo", 10)
            new Foo("foo", 10, (char) 20)
            new Foo("foo", 10, (char) 20, (short) 30)
            new Foo("foo", 10, (char) 20, (short) 30, 40L)
            new Foo("foo", 10, (char) 20, (short) 30, 40L, (byte) 50)
            new Foo("foo", 10, (char) 20, (short) 30, 40L, (byte) 50, 0.0)
            new Foo("foo", 10, (char) 20, (short) 30, 40L, (byte) 50, 0.0, 0.0F)
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
