
            import groovy.transform.builder.Builder

            @Builder
            class CookBook {
                List<String> recipes
            }

            def c = CookBook.builder().recipes(['Eggs Benedict', 'Poached Salmon']).build()
            assert c.recipes == ['Eggs Benedict', 'Poached Salmon']
        

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
