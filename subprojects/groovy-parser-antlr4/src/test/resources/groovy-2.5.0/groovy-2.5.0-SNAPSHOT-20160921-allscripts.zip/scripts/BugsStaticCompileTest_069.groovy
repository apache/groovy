
                class TwoException extends Exception {
                    @ASTTest(phase=INSTRUCTION_SELECTION,value={
                        def superCall = node.code.statements[0].expression
                        assert superCall.getNodeMetaData(DIRECT_METHOD_CALL_TARGET)!=null
                    })
                    public TwoException(Throwable t) {
                        super(t)
                    }
                }
                def e = new TwoException(null) // will not throw an exception
            

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
