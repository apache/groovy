
        class Dummy {
            def call(Object arguments) {"1"}
        }
        def c = new Dummy()
        assert c(2) == "1"      
      

// src/test/org/codehaus/groovy/classgen/CallClosureFieldAsMethodTest.groovy
