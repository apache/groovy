
            // tag::ann_member_string[]
            @interface SomeAnnotation {
                String value()                          // <1>
            }
            // end::ann_member_string[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
