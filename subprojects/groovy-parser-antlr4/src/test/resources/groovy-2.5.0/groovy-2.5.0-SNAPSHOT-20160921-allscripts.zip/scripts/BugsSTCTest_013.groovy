
        class A {}
        List<? extends GroovyObject> list = new LinkedList<? extends GroovyObject>()
        list.add(new A())
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
