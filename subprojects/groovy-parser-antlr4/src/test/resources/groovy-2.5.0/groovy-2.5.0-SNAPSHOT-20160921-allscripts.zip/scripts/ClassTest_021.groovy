
            // tag::ann_member_string_default[]
            @interface SomeAnnotation {
                String value() default 'something'      // <2>
            }
            // end::ann_member_string_default[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
