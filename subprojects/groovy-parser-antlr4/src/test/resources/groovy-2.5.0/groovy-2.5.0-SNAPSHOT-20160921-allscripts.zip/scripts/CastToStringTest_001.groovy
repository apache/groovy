
            byte[] bytes = "hello".bytes
            char[] chars = "hello".chars
            boolean[] flags = [true, false]
            long[] nums = [34L, 45L]
            String[] pets = ['cat', 'dog']

            String convert(byte[] data) { data }
            String convert(char[] data) { data }
            String convert(boolean[] data) { data }
            String convert(long[] data) { data }
            String convert(String[] data) { data }

            assert bytes.toString() == convert(bytes)
            assert chars.toString() == convert(chars)
            assert flags.toString() == convert(flags)
            assert nums.toString() == convert(nums)
            assert pets.toString() == convert(pets)
        

// src/test/org/codehaus/groovy/classgen/CastToStringTest.groovy
