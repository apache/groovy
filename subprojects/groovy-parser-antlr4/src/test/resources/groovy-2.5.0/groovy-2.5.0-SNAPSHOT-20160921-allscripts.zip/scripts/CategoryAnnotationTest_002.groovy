
            class ExceptionHandler {
                static def handled(Object self, Closure block) {
                    try { block.call() }
                    catch (Throwable t) { t.message }
                }
            }

            @Mixin(ExceptionHandler)
            class Caller {
                def thrower() { handled { 1/0 } }
            }

            assert new Caller().thrower() == 'Division by zero'
        

// src/test/groovy/lang/CategoryAnnotationTest.groovy
