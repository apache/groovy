
            package gls.annotations
            import java.lang.annotation.*
            @JavaAnnotation(in = 3)
            class Foo {}

            Annotation[] annotations = Foo.class.annotations
            assert annotations.size() == 1
            JavaAnnotation my = annotations[0]
            assert my.in() == 3
        

// src/test/gls/annotations/AnnotationTest.groovy
