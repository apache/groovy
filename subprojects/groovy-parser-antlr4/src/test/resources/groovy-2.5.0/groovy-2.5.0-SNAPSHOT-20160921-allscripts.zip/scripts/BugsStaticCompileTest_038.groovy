
                char incInt(char n) {
                    def result = n
                    ++result
                    result++
                    return result
                }
                assert  incInt((char)'a') == (char)('c')

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
