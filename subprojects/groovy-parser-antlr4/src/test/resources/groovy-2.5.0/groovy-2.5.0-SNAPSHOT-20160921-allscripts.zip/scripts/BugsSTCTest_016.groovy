
            Set tmp = null
            List other = (List) tmp // should not complain because source and target are interfaces
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
