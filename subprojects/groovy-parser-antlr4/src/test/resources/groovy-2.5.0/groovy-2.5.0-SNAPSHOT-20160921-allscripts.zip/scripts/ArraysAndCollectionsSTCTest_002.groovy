
            int[] arr2 = [1, 2, 3]
            arr2[1] = 4
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
