
                import groovy.beans.Bindable

                @Bindable final class BindableTestBean12  {
                  String testField
                  final String anotherTestField = 'Fixed'
                }

                sb = new BindableTestBean12()
                int changed = 0
                sb.propertyChange = {changed++}
                sb.testField = 'newValue'
                assert changed == 1

                sb.anotherTestField = 'Changed'
            

// src/test/groovy/beans/BindableTest.groovy
