package gep
            // tag::shout_example[]
            @Shout
            def greet() {
                println "Hello World"
            }

            greet()
            // end::shout_example[]
        

// src/spec/test/metaprogramming/ASTXFormSpecTest.groovy
