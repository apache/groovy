
            class Foo {
                int bar
            }
            Foo foo = null
            assert !(foo?.bar == 7)
            assert !(foo?.bar > 7)
            assert foo?.bar < 7
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
