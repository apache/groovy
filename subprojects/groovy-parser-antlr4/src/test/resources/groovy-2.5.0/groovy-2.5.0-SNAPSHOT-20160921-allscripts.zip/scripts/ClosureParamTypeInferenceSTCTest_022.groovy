
            String[] array = ['a','b','c']
            assert array.collectEntries([:]) { [it, it.toUpperCase() ]} == [a:'A',b:'B',c:'C']


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
