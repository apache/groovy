
            @groovy.transform.Canonical class Foo {
                String bar
                String baz = 'a'
            }
            
            def foo = new Foo(bar: 'c')
            def foo1 = new Foo(baz: 'd')
            assert 'a' == foo.baz
            assert 'c' == foo.bar
            assert 'd' == foo1.baz
            assert null == foo1.bar
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
