
    class Parent {
        String str
        Parent(String s) { str = s }
    }
    class Outer {
        private class Inner extends Parent {
           static String a = 'ok'
           Inner() { super(getA()) }
        }

        String test() { new Inner().str }
    }
    def o = new Outer()
    assert o.test() == 'ok'
    

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
