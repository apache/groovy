
            Serializable[] arr = ['abc']
            arr.putAt(0, new Integer(1))
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
