
            // checks special Map behavior isn't added if defaults=false
            import groovy.transform.*

            @ToString
            @TupleConstructor(defaults=false)
            class Person {
              def name
            }

            assert new Person('John Smith').toString() == 'Person(John Smith)'
            assert Person.constructors.size() == 1
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
