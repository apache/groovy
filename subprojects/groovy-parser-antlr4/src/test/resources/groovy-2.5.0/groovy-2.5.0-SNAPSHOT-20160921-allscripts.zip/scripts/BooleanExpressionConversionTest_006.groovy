
            boolean foo(byte i){
                if (i) return true
                return false
            }
            assert !foo((byte)0)
            assert foo((byte)1)
            assert !foo((byte)256)
        

// src/test/gls/types/BooleanExpressionConversionTest.groovy
