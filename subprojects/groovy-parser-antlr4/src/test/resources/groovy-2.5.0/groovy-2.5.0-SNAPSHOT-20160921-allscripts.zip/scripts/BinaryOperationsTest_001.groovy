
            $type[] b = new $type[1]
            b[0] = 16
            b[0] |= 2
            assert b[0] == 18:"Failure for type $type"
            

// src/test/org/codehaus/groovy/classgen/asm/BinaryOperationsTest.groovy
