
            abstract class Foo extends Script {
               def depth = 3
               def run() { myRun() }
               abstract myRun()
            }

            def run() {
               while (depth-- > 0) {
                  println "Going super"
                  super.run()
               }
            }

            @groovy.transform.BaseScript Foo foo
            println "hello world"
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
