
            // tag::ann_member_enum[]
            enum DayOfWeek { mon, tue, wed, thu, fri, sat, sun }
            @interface Scheduled {
                DayOfWeek dayOfWeek()                   // <6>
            }
            // end::ann_member_enum[]
            Scheduled
        

// src/spec/test/ClassTest.groovy
