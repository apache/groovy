
                import groovy.beans.Bindable

                class BindableTestBean9  {
                    void addPropertyChangeListener(java.beans.PropertyChangeListener l) {}
                }

                class BindableTestBean10 extends BindableTestBean9 {
                    @Bindable String testField
                }

                new BindableTestBean10()
            

// src/test/groovy/beans/BindableTest.groovy
