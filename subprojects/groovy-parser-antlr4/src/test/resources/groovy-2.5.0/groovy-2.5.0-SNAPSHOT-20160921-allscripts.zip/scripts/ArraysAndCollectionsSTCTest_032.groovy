
            String[] arr = ['abc']
            arr.putAt(0, 'def')
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
