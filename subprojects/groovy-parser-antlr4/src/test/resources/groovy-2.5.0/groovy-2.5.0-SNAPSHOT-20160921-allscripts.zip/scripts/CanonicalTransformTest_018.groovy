
              @groovy.transform.Canonical class HasListAndMap {
                  List nums
                  Map map
              }
              new HasListAndMap(nums:[], map:[:])
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
