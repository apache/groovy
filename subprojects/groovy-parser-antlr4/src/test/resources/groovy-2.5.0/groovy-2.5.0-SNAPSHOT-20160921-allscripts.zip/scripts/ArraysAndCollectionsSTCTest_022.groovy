
            for (int i in 1..10) { i*2 }
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
