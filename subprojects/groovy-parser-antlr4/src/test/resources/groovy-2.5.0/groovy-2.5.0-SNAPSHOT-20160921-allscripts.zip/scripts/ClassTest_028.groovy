
            // tag::annotation_value_set_option[]
            @interface Page {
                String value()
                int statusCode() default 200
            }

            @Page(value='/home')                    // <1>
            void home() {
                // ...
            }

            @Page('/users')                         // <2>
            void userList() {
                // ...
            }

            @Page(value='error',statusCode=404)     // <3>
            void notFound() {
                // ...
            }
            // end::annotation_value_set_option[]
        

// src/spec/test/ClassTest.groovy
