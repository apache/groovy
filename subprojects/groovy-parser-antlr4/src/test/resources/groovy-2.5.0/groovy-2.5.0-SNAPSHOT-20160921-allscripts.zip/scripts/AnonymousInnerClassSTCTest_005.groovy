
            abstract class Foo  implements Runnable { abstract String item() }
            Foo f = new Foo() {
                String item() { 'ok' }
                void run() {}
            }
            assert f.item() == 'ok'
            f.run()
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
