
            class Foo {
                long bar
                def method(Long v) {
                    setBar(v)
                    bar
                }
            }
            assert new Foo().method(-1L) == -1L
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
