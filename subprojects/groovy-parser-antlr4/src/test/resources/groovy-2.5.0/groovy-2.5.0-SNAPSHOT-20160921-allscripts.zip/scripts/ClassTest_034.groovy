
            import java.lang.annotation.Retention
            import java.lang.annotation.RetentionPolicy
            import groovy.transform.AnnotationCollector

            @Retention(RetentionPolicy.RUNTIME)
            @interface Timeout { int after() }
            @Retention(RetentionPolicy.RUNTIME)
            @interface Dangerous { String type() }

            // tag::collected_ann_explosive[]
            @Timeout(after=3600)
            @Dangerous(type='explosive')
            // end::collected_ann_explosive[]
            // tag::collector_ann_explosive[]
            @AnnotationCollector
            public @interface Explosive {}
            // end::collector_ann_explosive[]

            // tag::example_bomb[]
            @Explosive(after=0)                 // <1>
            class Bomb {}
            // end::example_bomb[]
            @Explosive
            class ReferenceBomb {}

            assert Bomb.getAnnotation(Timeout).after() == 0
            assert ReferenceBomb.getAnnotation(Timeout).after() == 3600
        

// src/spec/test/ClassTest.groovy
