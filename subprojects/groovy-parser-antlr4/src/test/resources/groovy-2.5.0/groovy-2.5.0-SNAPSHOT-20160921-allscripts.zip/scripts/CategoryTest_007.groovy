
            class A {
                private foo(a) { 1 }
                def baz() { foo() }
            }

            class B extends A {}

            class C {}

            use(C) {
                assert new B().baz() == 1
            }
        

// src/test/groovy/CategoryTest.groovy
