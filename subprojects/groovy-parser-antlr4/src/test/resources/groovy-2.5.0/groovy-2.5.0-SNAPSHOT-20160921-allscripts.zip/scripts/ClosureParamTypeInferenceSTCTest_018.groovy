
            assert ['a','b','c'].iterator().collectEntries([:]) { [it, it.toUpperCase() ]} == [a:'A',b:'B',c:'C']


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
