
            class Foo {
                static justcallme(Closure block) {
                    block()
                }
                static foo() {2}
                static bar(Closure block) {
                    this.justcallme {
                        this.foo()
                    }
                }
            }
            assert Foo.bar() {} == 2
        

// src/test/groovy/ClosureMethodCallTest.groovy
