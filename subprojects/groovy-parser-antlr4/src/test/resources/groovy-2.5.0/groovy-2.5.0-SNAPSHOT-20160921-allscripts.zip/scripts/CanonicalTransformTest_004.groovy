
            import groovy.transform.*
            @Canonical
            class Foo {
              int a
            }
            @Canonical(callSuper=true, includeSuperProperties=true, includeNames=true)
            class Bar extends Foo {
              int b
            }
            @Canonical(callSuper=true, includeSuper=true)
            @TupleConstructor(includeSuperProperties=true)
            class Baz extends Foo {
              int b
            }
            def (b1, b2, b3) = [new Bar(a:5, b:20), new Bar(10, 20), new Baz(15, 20)]
            assert [b1, b2, b3].toString() == '[Bar(b:20, a:5), Bar(b:20, a:10), Baz(20, Foo(15))]'
            assert b1 != b2
            assert b1.hashCode() != b2.hashCode()
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
