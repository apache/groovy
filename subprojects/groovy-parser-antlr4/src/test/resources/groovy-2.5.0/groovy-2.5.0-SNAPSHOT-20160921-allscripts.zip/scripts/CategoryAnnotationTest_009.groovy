
            @Mixin(Foo)
            class Bar { int x = 5 }

            @Category(Bar)
            class Foo {
                def foo() {
                    x
                }
            }

            assert new Bar().foo() == 5
        

// src/test/groovy/lang/CategoryAnnotationTest.groovy
