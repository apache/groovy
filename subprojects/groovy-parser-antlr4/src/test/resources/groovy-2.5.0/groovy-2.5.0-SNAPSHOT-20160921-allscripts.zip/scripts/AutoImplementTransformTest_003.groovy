
            @groovy.transform.AutoImplement
            class Foo implements Iterator<String> {
                String next() { 'foo' }
            }

            assert new Foo().next() == 'foo'
        

// src/test/org/codehaus/groovy/transform/AutoImplementTransformTest.groovy
