
            class A {}
            return new A()
        

// src/test/gls/invocation/ClassDuplicationTest.groovy
