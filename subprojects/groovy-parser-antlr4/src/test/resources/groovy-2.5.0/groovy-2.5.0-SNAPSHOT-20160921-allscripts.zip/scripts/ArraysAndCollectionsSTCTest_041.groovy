
        def m( Map param ) {
          def map = [ tim:4 ]
          map[ param.key ]
        }

        assert m( [ key: 'tim' ] ) == 4
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
