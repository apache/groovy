
            @BaseScript(DeclaredBaseScript)
            package foo

            import groovy.transform.BaseScript

            class DeclaredBaseScript extends Script {
                boolean iBeenRun
                def run() { iBeenRun = true }
            }


            assert !iBeenRun

            super.run()

            assert iBeenRun

            iBeenRun
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
