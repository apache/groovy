
            abstract class DeclaredBaseScript extends Script {
                int _meaningOfLife = 0
                int getMeaningOfLife() { _meaningOfLife }
                void setMeaningOfLife(int v) { _meaningOfLife = v }

                abstract def runScript()

                def preRun() { meaningOfLife |= 2 }
                def postRun() { meaningOfLife |= 8 }
                def run() {
                   preRun()
                   runScript()
                   postRun()
                   assert meaningOfLife == 42
                   meaningOfLife
                }
            }

            @groovy.transform.BaseScript DeclaredBaseScript baseScript

            meaningOfLife |= 32
            assert meaningOfLife == 34
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
