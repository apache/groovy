
            @groovy.transform.Canonical final class HasMap {
                Map map
            }
            def m = new HasMap([:])
            new HashMap()
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
