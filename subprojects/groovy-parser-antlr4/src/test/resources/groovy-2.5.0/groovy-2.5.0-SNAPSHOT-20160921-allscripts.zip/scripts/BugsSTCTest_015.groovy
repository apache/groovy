
        void testMethod(java.lang.Byte param){
            println(param)
        }

        void execute(){
            testMethod(java.lang.Byte.valueOf("123"))
        }

        execute()

// src/test/groovy/transform/stc/BugsSTCTest.groovy
