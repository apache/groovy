import groovy.transform.stc.FromString
import groovy.transform.stc.ClosureParams

void foo(@ClosureParams(value=FromString,options="java.lang.String") Closure cl) { cl.call('foo') }
foo { String str -> println str.toUpperCase()}


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
