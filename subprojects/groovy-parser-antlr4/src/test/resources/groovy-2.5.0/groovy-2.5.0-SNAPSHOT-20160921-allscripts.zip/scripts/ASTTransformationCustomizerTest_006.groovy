
            class A {}
            class B {}
            true
        

// src/test/org/codehaus/groovy/control/customizers/ASTTransformationCustomizerTest.groovy
