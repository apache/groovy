
            @groovy.transform.Canonical class Tree {
              Tree left, right
              Object item
            }

            def t = new Tree()
            t.left = t
            t.item = 4
            def s = new Tree()
            s.left = s
            s.item = 4
            assert s.equals(t)
            // not smart enough to handle mutual-recursion yet
            // don't use this annotation in such a scenario
            //
            // t.right = s
            // s.right = t
            // assert s.equals(t) // <= StackOverflowError
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
