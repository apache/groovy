
            abstract class CustomScript extends Script {}
  
            @groovy.transform.BaseScript CustomScript baseScript
            assert this == baseScript
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
