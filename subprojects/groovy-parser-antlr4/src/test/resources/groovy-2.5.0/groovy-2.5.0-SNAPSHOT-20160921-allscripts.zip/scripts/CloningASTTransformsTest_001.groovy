
// tag::example_autoclone[]
import groovy.transform.AutoClone

@AutoClone
class Book {
    String isbn
    String title
    List<String> authors
    Date publicationDate
}
// end::example_autoclone[]


def book = new Book(isbn: 'aaa', title: 'The Definitive Guide to cloning', authors:['Dolly'], publicationDate: new Date())
def clone = book.clone()
assert book.isbn == clone.isbn
assert book.title == clone.title
assert book.authors == clone.authors
assert book.publicationDate == clone.publicationDate
assert !(book.authors.is(clone.authors))


// src/spec/test/CloningASTTransformsTest.groovy
