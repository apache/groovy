
            @groovy.transform.TupleConstructor
            enum Operator {
                PLUS('+'), MINUS('-')
                String symbol
            }
            assert Operator.PLUS.next() == Operator.MINUS
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
