
            int sum(int x) { 1 }
            int sum(int y, int... args) {
                0
            }
            assert sum(1) == 1
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
