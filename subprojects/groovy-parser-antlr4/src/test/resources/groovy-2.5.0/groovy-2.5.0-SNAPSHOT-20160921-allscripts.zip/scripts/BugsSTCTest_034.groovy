
            interface A { void m() }
            interface B { void m() }
            interface C extends A,B {}
            class CImpl implements C, A,B {
                void m() {}
            }
            class D {
             D(C c) {
               c.m()
             }
            }

            new D(new CImpl())
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
