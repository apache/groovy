
            abstract class MyBaseClass extends Script {
                String name
                public void greet() { println "Hello, $name!" }
            }

            def shell = new GroovyShell(this.class.classLoader)
            shell.evaluate """
                // tag::use_basescript[]
                import groovy.transform.BaseScript

                @BaseScript MyBaseClass baseScript
                setName 'Judith'
                greet()
                // end::use_basescript[]
            """
        

// src/spec/test/BaseScriptSpecTest.groovy
