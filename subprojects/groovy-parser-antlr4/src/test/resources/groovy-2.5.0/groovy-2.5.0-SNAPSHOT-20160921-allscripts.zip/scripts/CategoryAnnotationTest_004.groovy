
            @Category(Guy)
            class Naming {
                String getTypeName() {
                    if(this.getType() != null)
                        this.getType().name
                    else
                        ""
                }
            }
            
            interface Guy {
                Type getType()
            }
            
            class Type {
                String name
            }
            
            class MyGuyver implements Guy {
                Type type
            }
            
            def atype = new Type(name: 'String')
            def onetest = new MyGuyver(type:atype)
            
            use(Naming) {
                assert onetest.getTypeName() == onetest.getType().getName()
            }
        

// src/test/groovy/lang/CategoryAnnotationTest.groovy
