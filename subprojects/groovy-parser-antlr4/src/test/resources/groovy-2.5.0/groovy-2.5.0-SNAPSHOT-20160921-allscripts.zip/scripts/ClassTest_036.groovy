import groovy.transform.AnnotationCollector
            import groovy.transform.CompileStatic
            import groovy.transform.TypeCheckingMode

            // tag::compiledynamic_naive[]
            @CompileStatic(TypeCheckingMode.SKIP)
            @AnnotationCollector
            public @interface CompileDynamic {}
            // end::compiledynamic_naive[]

            @CompileDynamic
            class Foo {}
            Foo
        

// src/spec/test/ClassTest.groovy
