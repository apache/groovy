
            def src = [a: 1, b:2, c:3]
            assert src.count { e -> e.value>1 } == 2
        

// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
