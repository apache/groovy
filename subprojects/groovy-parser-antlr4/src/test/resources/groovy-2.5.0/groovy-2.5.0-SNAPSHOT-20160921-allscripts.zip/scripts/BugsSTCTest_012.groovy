
        class A { static class B {} }
        GroovyObject obj = (GroovyObject)new A.B()
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
