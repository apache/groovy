import org.codehaus.groovy.control.CompilerConfiguration

            // tag::custom_run_method[]
            abstract class MyBaseClass extends Script {
                int count
                abstract void scriptBody()                              // <1>
                def run() {
                    count++                                             // <2>
                    scriptBody()                                        // <3>
                    count                                               // <4>
                }
            }
            // end::custom_run_method[]


            def conf = new CompilerConfiguration()
            conf.scriptBaseClass = 'MyBaseClass'
            def shell = new GroovyShell(this.class.classLoader, conf)

            // tag::custom_run_eval[]
            def result = shell.evaluate """
                println 'Ok'
            """
            assert result == 1
            // end::custom_run_eval[]

            // tag::custom_run_parse[]
            def script = shell.parse("println 'Ok'")
            assert script.run() == 1
            assert script.run() == 2
            // end::custom_run_parse[]
        

// src/spec/test/BaseScriptSpecTest.groovy
