
              @groovy.transform.Canonical class HasList {
                  String[] letters
                  List nums
              }
              def letters = 'A,B,C'.split(',')
              def nums = [1, 2]
              [new HasList(letters:letters, nums:nums),
               new HasList(letters, nums)]
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
