
            def foo() {
                List things = []
                Serializable s = new Serializable() {
                  def size() {
                    things.size()
                  }
                }
                s.size()
            }

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
