
            String name = 'Guillaume'
            for (String s in name) {
                println s
            }
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
