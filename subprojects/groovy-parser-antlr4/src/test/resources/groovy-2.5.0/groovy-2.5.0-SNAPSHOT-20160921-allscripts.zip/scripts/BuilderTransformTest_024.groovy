
            import groovy.transform.builder.*

            @Builder(builderStrategy = SimpleStrategy, allNames = true)
            class HasInternalPropertyWithSimpleStrategy {
                String $internal
            }
            assert new HasInternalPropertyWithSimpleStrategy().set$internal("foo").$internal == "foo"
         

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
