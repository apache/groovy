
            @groovy.transform.EqualsAndHashCode
            @groovy.transform.ToString
            class Demo {
                boolean myBooleanProperty

                boolean isMyBooleanProperty() {
                    false
                }

                static main(args) {
                    assert new Demo().hashCode() == 8730
                    assert new Demo(myBooleanProperty: true).toString() == 'Demo(false)'
                }
            }
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
