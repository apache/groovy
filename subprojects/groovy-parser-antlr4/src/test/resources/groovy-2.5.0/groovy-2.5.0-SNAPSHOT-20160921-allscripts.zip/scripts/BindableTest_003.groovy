
            class BindableTestBean3 {
                @groovy.beans.Bindable String name
                void setName(String newName) {
                     this.@name = "x\$newName"
                }
            }
            sb = new BindableTestBean3(name:"foo")
            changed = 0
            sb.propertyChange = {evt ->
                assert evt.newValue =~ '^x'
                changed++
            }
            sb.name = "baz"
            assert changed == 1
        

// src/test/groovy/beans/BindableTest.groovy
