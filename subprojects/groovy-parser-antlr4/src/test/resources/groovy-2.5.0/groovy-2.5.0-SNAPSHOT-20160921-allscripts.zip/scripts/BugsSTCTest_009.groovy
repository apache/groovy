
        class A {}
        GroovyObject obj = new A()
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
