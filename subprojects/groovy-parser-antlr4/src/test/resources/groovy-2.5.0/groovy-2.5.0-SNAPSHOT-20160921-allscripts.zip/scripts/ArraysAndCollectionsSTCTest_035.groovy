
            Serializable[] arr = ['abc']
            arr.putAt(0, 1)
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
