
        class Piece {
            int x() { 333 }
        }

        void foo() {
            Piece[] pieces = [new Piece(), null] as Piece[]
            int sum = 0
            for (int i=0;i<pieces.length;i++) {
                if (pieces[i]?.x()) {
                    sum += pieces[i].x()
                }
            }
            assert sum == 333
        }
        foo()
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
