
            class A {
                String name = 'foo'
            }
            List<A> myList = [new A(name:'Cedric'), new A(name:'Yakari')]
            for (element in myList) {
                element.name.toUpperCase()
            }
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
