
            ['a','b'].collect { it.toUpperCase() }
        

// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
