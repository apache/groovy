
            class Foo {
                int num
                String name

                Foo setNum(int num){
                    this.num = num
                    this
                }

                Foo setName(String name){
                    this.name = name
                    this
                }
            }
            Foo foo = new Foo().setNum(1).setName('fluent')
            assert foo.num == 1
            assert foo.name == 'fluent'
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
