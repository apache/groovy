
@BaseScript(CustomBase)
import groovy.transform.BaseScript

assert did_before
assert !did_after

42

abstract class CustomBase extends Script {
    boolean did_before = false
    boolean did_after = false

    def run() {
        before()
        def r = internalRun()
        after()
        assert r == 42
    }

    abstract internalRun()

    def before() { did_before = true }
    def after()  { did_after = true  }
}

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
