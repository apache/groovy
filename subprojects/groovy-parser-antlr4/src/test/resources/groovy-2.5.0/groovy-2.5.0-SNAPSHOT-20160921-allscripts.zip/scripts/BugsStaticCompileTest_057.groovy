
            class Groovy5921 {
              long[] data = [1L]

              void doSomething() {
                data[ 0 ] |= 0x7ffffffl
              }
            }

            def b = new Groovy5921()
            b.doSomething()

        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
