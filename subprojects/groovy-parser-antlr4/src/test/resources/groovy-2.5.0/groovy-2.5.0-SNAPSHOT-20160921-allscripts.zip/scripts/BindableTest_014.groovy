
            import groovy.beans.Bindable
            import groovy.transform.CompileStatic

            @CompileStatic
            class MyBean {
              @Bindable String test = "a test"
            }
            assert new MyBean()
        

// src/test/groovy/beans/BindableTest.groovy
