
            def a = new Dummy()
            Closure cl = {a.foo()}

            a.metaClass.foo {1}
            assert cl(1.5G) == 1

            a.metaClass.foo {2}
            assert cl(1.5G) == 2
            class Dummy {}
        

// src/test/org/codehaus/groovy/classgen/CallSiteTest.groovy
