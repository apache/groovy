
                class BindableTestBean4 {
                    public @groovy.beans.Bindable String name
                }
            

// src/test/groovy/beans/BindableTest.groovy
