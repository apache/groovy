
            import groovy.transform.*
            @Canonical
            @ToString(includeNames=true)
            @TupleConstructor(includeFields=true)
            class Rectangle {
                int w, h
                private int x, y
            }
            new Rectangle(10, 20, 5, 7).toString()
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
