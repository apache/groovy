
            class WithNext {
                String next() { 'foo' }
            }

            @groovy.transform.AutoImplement
            class Foo extends WithNext implements Iterator<String> { }
            assert new Foo().next() == 'foo'
        

// src/test/org/codehaus/groovy/transform/AutoImplementTransformTest.groovy
