
                class MyClass {
                    void doIt() { }
                }
                new MyClass().doIt()
            

// src/test/org/codehaus/groovy/control/customizers/ASTTransformationCustomizerTest.groovy
