
            @groovy.transform.Canonical class Foo {
                String bar
                String baz = 'a'
            }
            
            def foo = new Foo()
            def foo0 = new Foo('c')
            def foo1 = new Foo('c', 'd')
            assert null == foo.bar
            assert 'a' == foo.baz
            assert 'c' == foo0.bar
            assert 'a' == foo0.baz
            assert 'c' == foo1.bar
            assert 'd' == foo1.baz
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
