
            HashMap<String,List<List>> AR=new HashMap<String,List<List>>()
            AR.get('key',[['val1'],['val2']])
            assert AR.'key'[0] == ['val1']
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
