
            Object[] arr = [new Object()]
            arr.getAt(0)
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
