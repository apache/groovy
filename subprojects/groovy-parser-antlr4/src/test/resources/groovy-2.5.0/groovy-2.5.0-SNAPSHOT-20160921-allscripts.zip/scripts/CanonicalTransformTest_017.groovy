
              @groovy.transform.Canonical class HasListAndMap {
                  Object[] foo
              }
              def object = new HasListAndMap()
              def object2 = new HasListAndMap(['bar'] as Object[])
              
              assert object != object2
              
              object.foo = new Object[1]
              object.foo[0] = 'bar'
              
              assert object == object2
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
