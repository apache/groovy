
            import groovy.transform.builder.*
            import groovy.transform.*

            class Mamal {
                int age
            }

            @ToString(includeSuperProperties=true)
            @Builder(builderStrategy=InitializerStrategy, includeSuperProperties=true)
            class Person extends Mamal {
                String firstName
                String lastName
            }

            @CompileStatic
            def parentBuilder() {
                assert new Person(Person.createInitializer().firstName("John").lastName("Smith").age(21)).toString() == 'Person(John, Smith, 21)'
            }
            // static case
            parentBuilder()
            // dynamic case
            assert new Person(Person.createInitializer().firstName("John").lastName("Smith").age(21)).toString() == 'Person(John, Smith, 21)'
        

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
