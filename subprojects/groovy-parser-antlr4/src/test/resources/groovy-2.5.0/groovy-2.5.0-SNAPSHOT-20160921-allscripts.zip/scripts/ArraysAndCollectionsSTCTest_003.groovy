
            int[][] arr2 = new int[1][]
            arr2[0] = [1,2]
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
