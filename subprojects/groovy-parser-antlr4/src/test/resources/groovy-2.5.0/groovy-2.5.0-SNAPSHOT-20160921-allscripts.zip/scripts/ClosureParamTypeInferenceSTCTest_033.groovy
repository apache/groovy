import groovy.transform.stc.FromString
import groovy.transform.stc.ClosureParams

public <T> void foo(T t, @ClosureParams(value=FromString,options="java.util.List<T>") Closure cl) { cl.call([t,t]) }
foo('hey') { List<String> str -> str.each { println it.toUpperCase() } }


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
