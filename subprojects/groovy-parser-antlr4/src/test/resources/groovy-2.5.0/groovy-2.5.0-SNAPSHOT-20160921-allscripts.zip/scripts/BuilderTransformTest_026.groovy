
            import groovy.transform.builder.*

            @Builder(allNames = true)
            class HasInternalProperty {
                String $internal
            }

            assert HasInternalProperty.builder().$internal("foo").$internal == "foo"
         

// src/test/org/codehaus/groovy/transform/BuilderTransformTest.groovy
