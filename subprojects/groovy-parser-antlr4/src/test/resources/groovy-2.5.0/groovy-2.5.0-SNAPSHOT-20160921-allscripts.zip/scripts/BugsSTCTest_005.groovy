
        class L<E> extends ArrayList<E> {
            boolean removeIf(Comparator<? super E> filter) { }
        }
        L<String> items = ['foo', 'bar'] as L<String>
        items.removeIf({a, b -> 1} as Comparator<?>)
        assert items
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
