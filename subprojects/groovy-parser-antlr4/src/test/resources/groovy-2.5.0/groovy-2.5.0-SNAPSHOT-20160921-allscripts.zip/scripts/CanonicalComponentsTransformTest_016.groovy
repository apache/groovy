
            import groovy.transform.*

            @ToString @TupleConstructor(useSetters=true)
            class Foo1 {
                String bar, baz
                void setBar(String bar) {
                    this.bar = bar?.toUpperCase()
                }
            }

            assert new Foo1('cat', 'dog').toString() == 'Foo1(CAT, dog)'
            // check the default map-style constructor too
            assert new Foo1(bar: 'cat', baz: 'dog').toString() == 'Foo1(CAT, dog)'
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
