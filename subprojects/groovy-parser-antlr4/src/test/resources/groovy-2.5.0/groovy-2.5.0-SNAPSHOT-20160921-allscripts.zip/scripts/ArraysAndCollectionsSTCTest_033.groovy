
            String[] arr = ['abc']
            arr.putAt(0, null)
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
