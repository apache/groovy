
            abstract class  Foo extends Script {
               def run() {run(null)}
              abstract run(Object x)
            }

            @groovy.transform.BaseScript Foo foo
            println "hello world"
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
