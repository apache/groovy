
        assert [a: 'foo',b:'bar'].collect([]) { k,v -> k+v } == ['afoo','bbar']
        assert [a: 'foo',b:'bar'].collect([]) { e -> e.key+e.value } == ['afoo','bbar']
        assert [a: 'foo',b:'bar'].collect([]) { it.key+it.value } == ['afoo','bbar']


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
