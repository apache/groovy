
            @Mixin(Foo)
            class Bar {  }

            @Category(Bar)
            class Foo {
                int x = 5
                def foo() {
                    x
                }
            }

            assert new Bar().foo() == 5
            

// src/test/groovy/lang/CategoryAnnotationTest.groovy
