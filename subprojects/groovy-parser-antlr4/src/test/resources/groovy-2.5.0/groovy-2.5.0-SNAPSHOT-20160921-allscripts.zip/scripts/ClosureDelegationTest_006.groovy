
            class Foo {
                static aClosure = { foo() }
                static { aClosure.delegate = new Bar() }
            }
            class Bar {
                static visited
                def foo() { visited = true }
            }
            Foo.aClosure()
            assert Bar.visited == true
        

// src/test/gls/invocation/ClosureDelegationTest.groovy
