
            @groovy.transform.Canonical final class HasString {
                String s
            }
            def k1 = new HasString('xyz')
            def k2 = new HasString('xyz')
            def map = [(k1):42]
            assert map[k2] == 42
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
