
            // tag::ann_target[]
            import java.lang.annotation.ElementType
            import java.lang.annotation.Target

            @Target([ElementType.METHOD, ElementType.TYPE])     // <1>
            @interface SomeAnnotation {}                        // <2>
            // end::ann_target[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
