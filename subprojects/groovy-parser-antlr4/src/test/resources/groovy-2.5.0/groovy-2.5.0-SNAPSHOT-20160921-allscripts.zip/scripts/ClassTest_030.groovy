
            // tag::ann_retention[]
            import java.lang.annotation.Retention
            import java.lang.annotation.RetentionPolicy

            @Retention(RetentionPolicy.SOURCE)                   // <1>
            @interface SomeAnnotation {}                         // <2>
            // end::ann_retention[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
