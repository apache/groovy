
        List<Class> classes = null
        // this is ok
        assert classes?.name == null
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
