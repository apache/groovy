
            import groovy.transform.PreCompiledAlias 
            @PreCompiledAlias
            class Foo {
                Integer a, b
            }
            assert Foo.class.annotations.size()==3 
            assert new Foo(1,2).toString() == "Foo(1, 2)"
            assert PreCompiledAlias.value().length == 0
            assert PreCompiledAlias.value() instanceof Object[][]
        

// src/test/groovy/transform/AnnotationCollectorTest.groovy
