
            // tag::ann_member_class[]
            @interface SomeAnnotation {
                Class appliesTo()                       // <4>
            }
            // end::ann_member_class[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
