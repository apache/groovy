
def items = []
['a','b','c'].collect(items) { it.toUpperCase() }


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
