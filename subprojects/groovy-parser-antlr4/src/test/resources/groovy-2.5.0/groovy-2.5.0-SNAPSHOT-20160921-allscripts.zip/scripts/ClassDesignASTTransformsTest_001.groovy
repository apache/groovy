
// tag::delegating_class[]
class Event {
    @Delegate Date when
    String title
}
// end::delegating_class[]




// tag::delegation_assert[]
def ev = new Event(title:'Groovy keynote', when: Date.parse('yyyy/MM/dd', '2013/09/10'))
def now = new Date()
assert ev.before(now)
// end::delegation_assert[]


// src/spec/test/ClassDesignASTTransformsTest.groovy
