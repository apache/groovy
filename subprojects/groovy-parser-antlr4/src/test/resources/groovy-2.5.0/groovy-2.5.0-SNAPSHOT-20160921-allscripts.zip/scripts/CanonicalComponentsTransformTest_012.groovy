
            import org.codehaus.groovy.transform.*

            def orig = new Person7NestedAddressCS.Address7CS(street: 'somewhere lane', town: 'my town')
            def baos = new ByteArrayOutputStream()
            baos.withObjectOutputStream{ os -> os.writeObject(orig) }
            def bais = new ByteArrayInputStream(baos.toByteArray())
            bais.withObjectInputStream { is -> assert is.readObject().toString() == 'Person7NestedAddressCS$Address7CS(somewhere lane, my town)' }
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
