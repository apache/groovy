
            import groovy.transform.Canonical
            @Canonical class Foo {
                String value
            }
            @Canonical class Bar {
                String value
                String toString() { 'zzz' + _toString() }
            }
            @Canonical class Baz {
                String value
                String toString() { 'zzz' + _toString() }
                def _toString() { 'xxx' }
            }
            def foo = new Foo('abc')
            def foo0 = new Foo('abc')
            def foo1 = new Foo(value:'abc')
            def bar = new Bar('abc')
            def baz = new Baz('abc')
            assert bar.toString() == 'zzz' + foo.toString().replaceAll('Foo', 'Bar')
            assert baz.toString() == 'zzzxxx'

            assert 'Foo(abc)' == foo0.toString()
            foo0.value = 'cde'
            assert 'Foo(cde)' == foo0.toString()
            assert 'Foo(abc)' == foo1.toString()
            foo1.value = 'cde'
            assert 'Foo(cde)' == foo1.toString()
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
