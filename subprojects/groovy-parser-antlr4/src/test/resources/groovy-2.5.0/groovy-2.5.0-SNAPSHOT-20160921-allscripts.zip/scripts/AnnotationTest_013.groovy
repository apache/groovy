import gls.annotations.XmlEnum
            import gls.annotations.XmlEnumValue
            
            @XmlEnum
            enum GroovyEnum {
                @XmlEnumValue("good")
                BAD
            }
            assert GroovyEnum.class.getField('BAD').isAnnotationPresent(XmlEnumValue)
        

// src/test/gls/annotations/AnnotationTest.groovy
