
            // tag::field_declaration[]
            class Data {
                private int id                                  // <1>
                protected String description                    // <2>
                public static final boolean DEBUG = false       // <3>
            }
            // end::field_declaration[]
            def d = new Data()
        

// src/spec/test/ClassTest.groovy
