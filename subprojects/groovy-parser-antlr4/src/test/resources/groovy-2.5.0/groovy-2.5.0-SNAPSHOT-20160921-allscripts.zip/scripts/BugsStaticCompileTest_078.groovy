
class GrailsHomeWorkspaceReader {
    GrailsHomeWorkspaceReader(String grailsHome = System.getProperty('grails.home') ?: System.getenv('GRAILS_HOME')) {
    }
}
new GrailsHomeWorkspaceReader()


// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
