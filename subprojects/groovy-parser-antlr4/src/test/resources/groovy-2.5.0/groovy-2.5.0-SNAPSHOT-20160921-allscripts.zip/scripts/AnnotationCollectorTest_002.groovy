
            import groovy.transform.*
            @AnnotationCollector([ToString, EqualsAndHashCode, Immutable])
            @interface NotPreCompiledAlias {}

            @NotPreCompiledAlias
            class Foo {
                Integer a, b
            }
            assert Foo.class.annotations.size()==3
            assert new Foo(1,2).toString() == "Foo(1, 2)"
            assert NotPreCompiledAlias.value().length == 0
            assert NotPreCompiledAlias.value() instanceof Object[][]
        

// src/test/groovy/transform/AnnotationCollectorTest.groovy
