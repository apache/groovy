
            assert (0..5).iterator().collectMany { [it, 2*it ]} == [0,0,1,2,2,4,3,6,4,8,5,10]


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
