
            Serializable s = new Serializable() { List things = [1] }
            assert s.things.size() == 1
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
