
    class Parent {
        String str
        Parent(String s) { str = s }
    }
    class Outer {
        String a

        private class Inner extends Parent {
           Inner() { super(Outer.this.getA()) }
        }

        String test() { new Inner().str }
    }
    def o = new Outer(a:'ok')
    assert o.test() == 'ok'
    

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
