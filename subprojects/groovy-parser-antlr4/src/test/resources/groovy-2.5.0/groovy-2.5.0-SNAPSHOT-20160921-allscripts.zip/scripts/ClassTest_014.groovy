
            // tag::properties_definition[]
            class Person {
                String name                             // <1>
                int age                                 // <2>
            }
            // end::properties_definition[]

            assert Person.declaredFields.name.containsAll (['name','age'])
            assert Person.getDeclaredMethod('getName')
            assert Person.getDeclaredMethod('getAge')
            assert Person.getDeclaredMethod('setName',String)
            assert Person.getDeclaredMethod('setAge',int)
        

// src/spec/test/ClassTest.groovy
