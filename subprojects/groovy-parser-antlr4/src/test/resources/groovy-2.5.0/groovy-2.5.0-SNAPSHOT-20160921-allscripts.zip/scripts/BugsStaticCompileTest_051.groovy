
        Map<String, Map<String,Map<String,Integer>>> m=[:]
        // this is ok
        assert m?.a == null
        assert m?.a?.b == null
        assert m?.a?.b?.c == null
        assert m?.a?.b?.c?.intValue() == null
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
