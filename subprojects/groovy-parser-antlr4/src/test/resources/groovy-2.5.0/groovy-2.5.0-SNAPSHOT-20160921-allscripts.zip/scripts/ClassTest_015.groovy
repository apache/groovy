
            // tag::readonly_property[]
            class Person {
                final String name                   // <1>
                final int age                       // <2>
                Person(String name, int age) {
                    this.name = name                // <3>
                    this.age = age                  // <4>
                }
            }
            // end::readonly_property[]

            def p = new Person('Bob', 42)
            assert Person.declaredFields.name.containsAll (['name','age'])
            assert Person.getDeclaredMethod('getName')
            assert Person.getDeclaredMethod('getAge')
            try {
                assert Person.getDeclaredMethod('setName',String) == null
            } catch (NoSuchMethodException e) {

            }
            try {
                assert Person.getDeclaredMethod('setAge',int) == null
            } catch (NoSuchMethodException e) {

            }

        

// src/spec/test/ClassTest.groovy
