
            i=1
            for (i in [2,3]) {}
            assert i==1
        

// src/test/gls/scope/BlockScopeVisibilityTest.groovy
