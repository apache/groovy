
                void foo() {
                int idx = 0
                def cl = { idx }
                }
            

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
