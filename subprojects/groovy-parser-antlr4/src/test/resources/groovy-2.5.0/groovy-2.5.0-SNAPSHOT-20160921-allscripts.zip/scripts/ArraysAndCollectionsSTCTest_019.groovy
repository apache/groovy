
            [1,2,3].collect { it.toString() }
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
