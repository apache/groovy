
            @Grab('javax.servlet:javax.servlet-api:3.0.1')
            import groovy.transform.CompileStatic

            import javax.servlet.ServletContext
            import javax.servlet.ServletRegistration

            

            @CompileStatic
            class ServletExample {

              public void myMethod(ServletContext ctx) {
                ctx.getServletRegistrations().each { String name, ServletRegistration sr ->
                  println name
                }

              }
            }
            new ServletExample()
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
