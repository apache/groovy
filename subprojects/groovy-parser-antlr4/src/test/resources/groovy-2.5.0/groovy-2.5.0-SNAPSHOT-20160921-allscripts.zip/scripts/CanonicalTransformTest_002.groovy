
                @groovy.transform.Canonical class Foo {
                    def foo, bar, baz
                
                    Foo() {}
                
                    Foo(foo, bar) {
                        this.foo = foo
                        this.bar = bar
                    }
                }
            
                def foo = new Foo('a', 'b')
                def foo1 = new Foo()
                foo1.foo = 'a'
                foo1.bar = 'b'
                assert foo == foo1
            
                // Fail here
                new Foo('a', 'b', 'c')
            

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
