
            def foo = [] + []
            assert foo==[]
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
