class Inner {
    int somestuff
}
Inner inner = null
int someInt = inner?.somestuff ?: 0
println someInt



// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
