
            def map = [a:1, b:2]
            map = [b:2, c:3]
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
