
// tag::delegate_example_allNames[]
class Worker {
    void task$() {}
}
class Delegating {
    @Delegate(allNames=true) Worker worker = new Worker()
}
def d = new Delegating()
d.task$() //passes
// end::delegate_example_allNames[]


// src/spec/test/ClassDesignASTTransformsTest.groovy
