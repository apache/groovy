
            List<String> list = ['a','b']
            list += ['c']
            assert list == ['a','b','c']
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
