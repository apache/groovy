
            def date = new Date()
            def array = [1, 2, 3] as Integer[]
            def map = [foo: 'bar']
            def collection = [4, 5, 6]
            
            @groovy.transform.Canonical class Foo {
                Date date
                Integer[] array
                Map map
                Collection collection
            }
            
            def foo = new Foo(date, array, map, collection)
            
            assert date.is(foo.date)
            assert array.is(foo.array)
            assert map.is(foo.map)
            assert collection.is(foo.collection)
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
