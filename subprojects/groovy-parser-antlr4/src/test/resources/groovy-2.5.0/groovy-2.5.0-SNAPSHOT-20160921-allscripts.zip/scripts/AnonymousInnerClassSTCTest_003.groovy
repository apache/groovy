
            Runnable r = new Runnable() {
                public void run() { println 'ok' }
            }
            r.run()
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
