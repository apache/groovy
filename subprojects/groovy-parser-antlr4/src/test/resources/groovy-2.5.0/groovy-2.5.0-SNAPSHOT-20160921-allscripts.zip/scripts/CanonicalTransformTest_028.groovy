
            @groovy.transform.Canonical class Tree {
                Object item
                Tree left, right
            }

            def t = new Tree(4)
            t.left = t
            t.right = t
            assert t.hashCode() == 7497
            // not smart enough to handle mutual-recursion yet
            // don't use this annotation in such a scenario
            //
            // def s = new Tree(5, t)
            // t.left = s
            // println t.hashCode() // <= StackOverflowError
        

// src/test/org/codehaus/groovy/transform/CanonicalTransformTest.groovy
