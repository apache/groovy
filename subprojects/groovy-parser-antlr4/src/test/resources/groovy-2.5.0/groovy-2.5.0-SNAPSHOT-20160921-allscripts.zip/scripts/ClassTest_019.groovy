
            // tag::define_annotation[]
            @interface SomeAnnotation {}
            // end::define_annotation[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
