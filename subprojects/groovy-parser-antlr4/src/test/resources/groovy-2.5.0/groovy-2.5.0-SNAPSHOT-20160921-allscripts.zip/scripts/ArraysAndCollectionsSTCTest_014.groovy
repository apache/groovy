
            Map map = [a:1, b:2]
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
