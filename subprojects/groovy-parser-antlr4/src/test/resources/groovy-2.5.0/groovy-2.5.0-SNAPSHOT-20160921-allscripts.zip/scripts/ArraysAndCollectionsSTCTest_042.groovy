
        Integer[] m() {
          Integer[] arr = [ null, null ]
        }
        assert m().length == 2
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
