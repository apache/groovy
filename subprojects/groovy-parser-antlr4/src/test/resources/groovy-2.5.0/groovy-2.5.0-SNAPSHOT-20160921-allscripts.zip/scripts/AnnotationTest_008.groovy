
            @Singleton class MyService3410{}
            assert MyService3410.instance != null
            assert MyService3410.getInstance() != null
      

// src/test/gls/annotations/AnnotationTest.groovy
