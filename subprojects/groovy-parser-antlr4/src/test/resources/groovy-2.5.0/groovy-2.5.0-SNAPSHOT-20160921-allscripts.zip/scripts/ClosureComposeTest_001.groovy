
            def a = { foo }
            def b = { bar }

            class O {
                def foo = 'foo'
                def bar = 'bar'
            }

            def ab = a >> b
            ab.delegate = new O()
            ab()
        

// src/test/groovy/ClosureComposeTest.groovy
