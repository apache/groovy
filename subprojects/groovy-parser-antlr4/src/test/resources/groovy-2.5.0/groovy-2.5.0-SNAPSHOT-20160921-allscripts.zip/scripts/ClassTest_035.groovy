

import groovy.transform.AnnotationCollector

import java.lang.annotation.Retention
            import java.lang.annotation.RetentionPolicy

            // tag::collector_ann_same_values[]
            @Retention(RetentionPolicy.RUNTIME)
            public @interface Foo {
               String value()                                   // <1>
            }
            @Retention(RetentionPolicy.RUNTIME)
            public @interface Bar {
                String value()                                  // <2>
            }

            @Foo
            @Bar
            @AnnotationCollector
            public @interface FooBar {}                         // <3>

            @Foo('a')
            @Bar('b')
            class Bob {}                                        // <4>

            assert Bob.getAnnotation(Foo).value() == 'a'        // <5>
            println Bob.getAnnotation(Bar).value() == 'b'       // <6>

            @FooBar('a')
            class Joe {}                                        // <7>
            assert Joe.getAnnotation(Foo).value() == 'a'        // <8>
            println Joe.getAnnotation(Bar).value() == 'a'       // <9>
            // end::collector_ann_same_values[]
        

// src/spec/test/ClassTest.groovy
