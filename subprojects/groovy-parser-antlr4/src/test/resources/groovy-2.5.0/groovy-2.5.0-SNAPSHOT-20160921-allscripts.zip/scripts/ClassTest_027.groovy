
            // tag::annotation_value_set[]
            @interface Page {
                int statusCode()
            }

            @Page(statusCode=404)
            void notFound() {
                // ...
            }
            // end::annotation_value_set[]
        

// src/spec/test/ClassTest.groovy
