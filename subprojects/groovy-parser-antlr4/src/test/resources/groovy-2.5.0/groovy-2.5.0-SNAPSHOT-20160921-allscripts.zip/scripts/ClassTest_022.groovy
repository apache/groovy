
            // tag::ann_member_int[]
            @interface SomeAnnotation {
                int step()                              // <3>
            }
            // end::ann_member_int[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
