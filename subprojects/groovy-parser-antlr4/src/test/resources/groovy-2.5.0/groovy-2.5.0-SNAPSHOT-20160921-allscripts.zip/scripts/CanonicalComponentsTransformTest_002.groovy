
            import groovy.transform.*

            @EqualsAndHashCode
            @CompileStatic
            class Person {
                Character someCharacter
                Integer someInteger
                Long someLong
                Float someFloat
                Double someDouble
            }

            assert new Person().hashCode()
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
