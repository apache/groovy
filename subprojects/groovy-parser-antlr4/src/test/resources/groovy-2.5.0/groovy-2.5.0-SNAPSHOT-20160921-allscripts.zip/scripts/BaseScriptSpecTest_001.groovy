import org.codehaus.groovy.control.CompilerConfiguration
            // tag::baseclass_def[]
            abstract class MyBaseClass extends Script {
                String name
                public void greet() { println "Hello, $name!" }
            }
            // end::baseclass_def[]

            // tag::use_custom_conf[]
            def config = new CompilerConfiguration()                                // <1>
            config.scriptBaseClass = 'MyBaseClass'                                  // <2>
            def shell = new GroovyShell(this.class.classLoader, config)             // <3>
            shell.evaluate """
                setName 'Judith'                                                    // <4>
                greet()
            """
            // end::use_custom_conf[]
        

// src/spec/test/BaseScriptSpecTest.groovy
