
            import java.lang.annotation.Retention
            import java.lang.annotation.RetentionPolicy
            import java.lang.reflect.Modifier
            // tag::closure_ann_def[]
            @Retention(RetentionPolicy.RUNTIME)
            @interface OnlyIf {
                Class value()                    // <1>
            }
            // end::closure_ann_def[]

            // tag::closure_ann_example[]
            class Tasks {
                Set result = []
                void alwaysExecuted() {
                    result << 1
                }
                @OnlyIf({ jdk>=6 })
                void supportedOnlyInJDK6() {
                    result << 'JDK 6'
                }
                @OnlyIf({ jdk>=7 && windows })
                void requiresJDK7AndWindows() {
                    result << 'JDK 7 Windows'
                }
            }
            // end::closure_ann_example[]

            // tag::closure_ann_runner[]
            class Runner {
                static <T> T run(Class<T> taskClass) {
                    def tasks = taskClass.newInstance()                                         // <1>
                    def params = [jdk:6, windows: false]                                        // <2>
                    tasks.class.declaredMethods.each { m ->                                     // <3>
                        if (Modifier.isPublic(m.modifiers) && m.parameterTypes.length == 0) {   // <4>
                            def onlyIf = m.getAnnotation(OnlyIf)                                // <5>
                            if (onlyIf) {
                                Closure cl = onlyIf.value().newInstance(tasks,tasks)            // <6>
                                cl.delegate = params                                            // <7>
                                if (cl()) {                                                     // <8>
                                    m.invoke(tasks)                                             // <9>
                                }
                            } else {
                                m.invoke(tasks)                                                 // <10>
                            }
                        }
                    }
                    tasks                                                                       // <11>
                }
            }
            // end::closure_ann_runner[]

            // tag::closure_ann_runner_exec[]
            def tasks = Runner.run(Tasks)
            assert tasks.result == [1, 'JDK 6'] as Set
            // end::closure_ann_runner_exec[]
        

// src/spec/test/ClassTest.groovy
