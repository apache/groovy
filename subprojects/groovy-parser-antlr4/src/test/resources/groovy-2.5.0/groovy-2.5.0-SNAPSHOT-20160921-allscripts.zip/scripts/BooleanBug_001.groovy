
            def foo(x){x}
            def i = 0
            assert foo(i==0)==true
        

// src/test/groovy/bugs/BooleanBug.groovy
