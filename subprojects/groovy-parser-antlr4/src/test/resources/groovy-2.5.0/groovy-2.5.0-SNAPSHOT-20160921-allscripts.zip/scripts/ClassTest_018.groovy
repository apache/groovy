
            // tag::pseudo_properties[]
            class PseudoProperties {
                // a pseudo property "name"
                void setName(String name) {}
                String getName() {}

                // a pseudo read-only property "age"
                int getAge() { 42 }

                // a pseudo write-only property "groovy"
                void setGroovy(boolean groovy) {  }
            }
            def p = new PseudoProperties()
            p.name = 'Foo'                      // <1>
            assert p.age == 42                  // <2>
            p.groovy = true                     // <3>
            // end::pseudo_properties[]
        

// src/spec/test/ClassTest.groovy
