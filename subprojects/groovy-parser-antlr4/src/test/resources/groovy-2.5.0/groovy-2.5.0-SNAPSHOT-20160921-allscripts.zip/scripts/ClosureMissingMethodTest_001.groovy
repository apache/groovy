
          int count = 0

          foo = {
            count++
            bar()
          }
          baz = {
            foo()
          }

          try {
              baz()
              fail()
          } catch (org.codehaus.groovy.runtime.InvokerInvocationException iie) {
              assert iie.cause.method == 'bar'
              assert count == 1
          } catch (MissingMethodException mme) {
              assert mme.method == 'bar'
              assert count == 1
          }
      

// src/test/groovy/ClosureMissingMethodTest.groovy
