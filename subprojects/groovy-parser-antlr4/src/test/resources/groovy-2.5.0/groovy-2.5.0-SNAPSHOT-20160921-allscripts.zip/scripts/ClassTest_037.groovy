import groovy.transform.AnnotationCollector
            import groovy.transform.CompileStatic
            import groovy.transform.TypeCheckingMode
            import org.codehaus.groovy.ast.AnnotatedNode
            import org.codehaus.groovy.ast.AnnotationNode
            import org.codehaus.groovy.ast.ClassHelper
            import org.codehaus.groovy.ast.ClassNode
            import org.codehaus.groovy.ast.expr.ClassExpression
            import org.codehaus.groovy.ast.expr.PropertyExpression
            import org.codehaus.groovy.control.SourceUnit
            import org.codehaus.groovy.transform.AnnotationCollectorTransform

            // tag::compiledynamic_def_fixed[]
            @AnnotationCollector(processor = "org.codehaus.groovy.transform.CompileDynamicProcessor")
            public @interface CompileDynamic {
            }
            // end::compiledynamic_def_fixed[]

            // tag::compiledynamic_processor[]
            @CompileStatic                                                                  // <1>
            class CompileDynamicProcessor extends AnnotationCollectorTransform {            // <2>
                private static final ClassNode CS_NODE = ClassHelper.make(CompileStatic)    // <3>
                private static final ClassNode TC_NODE = ClassHelper.make(TypeCheckingMode) // <4>

                List<AnnotationNode> visit(AnnotationNode collector,                        // <5>
                                           AnnotationNode aliasAnnotationUsage,             // <6>
                                           AnnotatedNode aliasAnnotated,                    // <7>
                                           SourceUnit source) {                             // <8>
                    def node = new AnnotationNode(CS_NODE)                                  // <9>
                    def enumRef = new PropertyExpression(
                        new ClassExpression(TC_NODE), "SKIP")                               // <10>
                    node.addMember("value", enumRef)                                        // <11>
                    Collections.singletonList(node)                                         // <12>
                }
            }
            // end::compiledynamic_processor[]

            @CompileDynamic
            class Foo {}
            Foo
        

// src/spec/test/ClassTest.groovy
