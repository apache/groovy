
            class Foo {
                static visited 
                static closureInStaticContext = {
                    foo()
                }
                static foo(){ visited = true }
            }
            Foo.closureInStaticContext()
            assert Foo.visited == true
        

// src/test/gls/invocation/ClosureDelegationTest.groovy
