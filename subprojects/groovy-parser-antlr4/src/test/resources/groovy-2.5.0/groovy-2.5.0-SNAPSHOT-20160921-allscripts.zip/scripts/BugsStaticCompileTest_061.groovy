
                int sum(Object... elems) {
                     (Integer)elems.toList().sum()
                }
                int x = sum(Closure.DELEGATE_FIRST)
                assert x == Closure.DELEGATE_FIRST
            

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
