
            class BigDecimalBug {
                
                  BigDecimal advancePaid = 100.00
                  BigDecimal advanceApplied = 10.00
                  BigDecimal advanceHeld = 20.00
                  BigDecimal advanceAdj = 50.00
                
                  void testAdvanceAvailable() {
                    def tmp = advancePaid + advanceApplied + advanceHeld + advanceAdj;
                    assert tmp.getClass() == BigDecimal
                  }  
            }
            def bug = new BigDecimalBug()
            bug.testAdvanceAvailable()
        

// src/test/groovy/operator/BigDecimalOperatorsTest.groovy
