
            assert 4294967296
            assert 0.1f
            assert 0.1d
        

// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
