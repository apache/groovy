
                import groovy.beans.Bindable

                class BindableTestBean8  {
                    @Bindable String testField
                    void addPropertyChangeListener(java.beans.PropertyChangeListener l) {}
                }
                new BindableTestBean8()
            

// src/test/groovy/beans/BindableTest.groovy
