
            @ASTTest(phase=INSTRUCTION_SELECTION, value={
                assert node.getNodeMetaData(INFERRED_TYPE) == int_TYPE.makeArray().makeArray()
            })
            int[][] array = [[1]] as int[][]
            array[0].length
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
