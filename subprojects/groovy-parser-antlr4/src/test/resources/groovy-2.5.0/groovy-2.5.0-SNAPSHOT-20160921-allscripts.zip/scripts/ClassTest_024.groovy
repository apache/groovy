
            // tag::ann_member_annotation[]
            @interface SomeAnnotation {}
            @interface SomeAnnotations {
                SomeAnnotation[] value()                // <5>
            }
            // end::ann_member_annotation[]
            SomeAnnotation
        

// src/spec/test/ClassTest.groovy
