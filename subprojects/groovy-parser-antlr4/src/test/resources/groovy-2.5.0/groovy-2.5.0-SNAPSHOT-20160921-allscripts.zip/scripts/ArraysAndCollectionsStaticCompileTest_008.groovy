
                class Foo {
                    static void test() {
                        def list = ['a', 'b']
                        def lengths = list.toList()*.length()
                        assert lengths == [1, 1]
                    }
                }
                Foo.test()
            

// src/test/org/codehaus/groovy/classgen/asm/sc/ArraysAndCollectionsStaticCompileTest.groovy
