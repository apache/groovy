
            // tag::typing_fields[]
            class BadPractice {
                private mapping                         // <1>
            }
            class GoodPractice {
                private Map<String,String> mapping      // <2>
            }
            // end::typing_fields[]
            BadPractice
        

// src/spec/test/ClassTest.groovy
