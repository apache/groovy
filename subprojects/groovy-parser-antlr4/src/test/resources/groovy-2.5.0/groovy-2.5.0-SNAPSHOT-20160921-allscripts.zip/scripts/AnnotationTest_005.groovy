
            import java.lang.annotation.*

            @Deprecated
            class Foo{}

            assert Foo.class.annotations.size() == 1
        

// src/test/gls/annotations/AnnotationTest.groovy
