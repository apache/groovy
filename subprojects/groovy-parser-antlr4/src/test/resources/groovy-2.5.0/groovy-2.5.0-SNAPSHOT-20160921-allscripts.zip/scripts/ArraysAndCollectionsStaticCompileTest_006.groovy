
                class Foo {
                    static void test() {
                        def list = [1, 2]
                        def lengths = [list << 3]*.size()
                        assert lengths == [3]
                        assert list == [1, 2, 3]
                    }
                }
                Foo.test()
            

// src/test/org/codehaus/groovy/classgen/asm/sc/ArraysAndCollectionsStaticCompileTest.groovy
