
            abstract class CustomScript extends Script {}
  
            @groovy.transform.BaseScript CustomScript baseScript
            assert this.class.superclass == CustomScript
        

// src/test/org/codehaus/groovy/transform/BaseScriptTransformTest.groovy
