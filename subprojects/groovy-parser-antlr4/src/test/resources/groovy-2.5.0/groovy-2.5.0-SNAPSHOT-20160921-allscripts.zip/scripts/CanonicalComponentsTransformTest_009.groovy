
            @groovy.transform.Canonical
            class Person {
              @Lazy first = missing()
              @Lazy last = 'Smith'
              int age
            }
            def p = new Person(21)
            // $first setter is an implementation detail
            p.$first = 'Mary'
            p.toString()
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
