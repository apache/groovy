
            int m() {
                int[] arr = [1,2,3]
                arr.getAt(1)
            }
            assert m()==2
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
