
            Object[] arr = [new Object()]
            arr.putAt(0, new Object())
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
