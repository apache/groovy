
            def o
            boolean b = true
            if (b) {
                o = 1
            } else {
                @ASTTest(phase=INSTRUCTION_SELECTION, value={
                    assert node.getNodeMetaData(INFERRED_TYPE) == OBJECT_TYPE
                })
                def o2 = o
                o2 = 'foo'
                println (o2.toString())
            }
        

// src/test/groovy/transform/stc/BugsSTCTest.groovy
