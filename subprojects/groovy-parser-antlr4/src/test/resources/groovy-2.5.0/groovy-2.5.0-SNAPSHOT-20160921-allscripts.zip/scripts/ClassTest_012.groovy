
            class IDGenerator { static int next() {0} }
            // tag::field_initialization[]
            class Data {
                private String id = IDGenerator.next() // <1>
                // ...
            }
            // end::field_initialization[]
            new Data()
        

// src/spec/test/ClassTest.groovy
