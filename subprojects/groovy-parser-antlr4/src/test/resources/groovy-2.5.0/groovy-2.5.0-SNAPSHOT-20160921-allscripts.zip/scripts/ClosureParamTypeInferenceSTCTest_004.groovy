
            ['a','b'].each { it.toUpperCase() }
        

// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
