import groovy.transform.stc.FromString
import groovy.transform.stc.ClosureParams

void foo(@ClosureParams(value=FromString,options="java.util.List<java.lang.String>") Closure cl) { cl.call(['foo']) }
foo { List<String> str -> str.each { println it.toUpperCase() } }


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
