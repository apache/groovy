
            import java.util.concurrent.atomic.AtomicLong

            class Sequencer {
              private final AtomicLong sequenceNumber = new AtomicLong(0)

              public Long getNext() {
                return sequenceNumber.getAndIncrement()
              }
            }

            final seq = new Sequencer()
            (1..5).each {
              println seq.next?.longValue()
            }
            assert seq.next == 5


// src/test/org/codehaus/groovy/classgen/asm/sc/BugsStaticCompileTest.groovy
