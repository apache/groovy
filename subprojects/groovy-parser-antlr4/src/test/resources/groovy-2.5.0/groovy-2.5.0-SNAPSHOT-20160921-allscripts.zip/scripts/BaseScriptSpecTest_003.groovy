
            abstract class MyBaseClass extends Script {
                String name
                public void greet() { println "Hello, $name!" }
            }

            def shell = new GroovyShell(this.class.classLoader)
            shell.evaluate """
                // tag::use_basescript_alt[]
                @BaseScript(MyBaseClass)
                import groovy.transform.BaseScript

                setName 'Judith'
                greet()
                // end::use_basescript_alt[]
            """
        

// src/spec/test/BaseScriptSpecTest.groovy
