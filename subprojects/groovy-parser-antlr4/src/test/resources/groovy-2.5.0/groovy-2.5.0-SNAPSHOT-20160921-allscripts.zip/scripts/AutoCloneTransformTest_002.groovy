
                    import groovy.transform.AutoClone

                    @AutoClone(excludes='sirName')
                    class Person {
                        String firstName
                        String surName
                    }

                    new Person(firstName: "John", surName: "Doe").clone()
                

// src/test/org/codehaus/groovy/transform/AutoCloneTransformTest.groovy
