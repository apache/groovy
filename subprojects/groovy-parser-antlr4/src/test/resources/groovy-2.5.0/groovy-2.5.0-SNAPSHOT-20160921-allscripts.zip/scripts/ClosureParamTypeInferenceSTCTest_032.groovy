import groovy.transform.stc.FromString
import groovy.transform.stc.ClosureParams

public <T> void foo(T t, @ClosureParams(value=FromString,options="T") Closure cl) { cl.call(t) }
foo('hey') { println it.toUpperCase() }


// src/test/groovy/transform/stc/ClosureParamTypeInferenceSTCTest.groovy
