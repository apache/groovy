
            boolean foo(short i){
                if (i) return true
                return false
            }
            assert !foo((short)0)
            assert foo((short)1)
            assert foo((short)256)
        

// src/test/gls/types/BooleanExpressionConversionTest.groovy
