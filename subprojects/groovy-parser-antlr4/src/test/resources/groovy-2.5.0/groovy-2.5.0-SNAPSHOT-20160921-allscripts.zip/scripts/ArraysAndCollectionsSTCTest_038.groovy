List<Integer> list = [ 1, 2, 3, 4 ]

        @ASTTest(phase=INSTRUCTION_SELECTION, value= {
            assert node.getNodeMetaData(INFERRED_TYPE) == Integer_TYPE
        })
        Integer j = org.codehaus.groovy.runtime.DefaultGroovyMethods.find(list) { int it -> it%2 == 0 }

        @ASTTest(phase=INSTRUCTION_SELECTION, value= {
            assert node.getNodeMetaData(INFERRED_TYPE) == Integer_TYPE
        })
        Integer i = list.find { int it -> it % 2 == 0 }
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
