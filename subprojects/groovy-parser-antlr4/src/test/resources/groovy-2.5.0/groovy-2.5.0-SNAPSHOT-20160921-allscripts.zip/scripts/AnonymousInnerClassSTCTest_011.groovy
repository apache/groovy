
            interface X {
                def m()
            }

            class A {
                Object pm = "pm"
                def bar(Closure<? extends X> x) {x().m()}
                def foo() {
                    bar { ->
                        return new X() {
                            def m() { pm }
                        }
                    }
                }
            }
            def a = new A()
            assert a.foo() == "pm"
        

// src/test/groovy/transform/stc/AnonymousInnerClassSTCTest.groovy
