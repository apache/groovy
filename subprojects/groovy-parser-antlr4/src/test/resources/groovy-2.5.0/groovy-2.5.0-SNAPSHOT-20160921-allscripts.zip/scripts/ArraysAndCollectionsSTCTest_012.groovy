
            List list = ['a','b','c']
            List classes = list*.toUpperCase()
            assert classes == ['A','B','C']
        

// src/test/groovy/transform/stc/ArraysAndCollectionsSTCTest.groovy
