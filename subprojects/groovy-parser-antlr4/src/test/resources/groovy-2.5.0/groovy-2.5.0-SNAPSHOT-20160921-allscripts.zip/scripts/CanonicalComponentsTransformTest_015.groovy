
            import groovy.transform.AutoClone
            @AutoClone
            class B {
              String name='B'
            }

            @AutoClone
            class A {
              B b
              C c
              ArrayList x
              List y
              String name='A'
            }

            @AutoClone
            class C {
              String name='C'
            }

            def b = new B().clone()
            assert b
            assert new A(b:b).clone()
            assert new A().clone()
        

// src/test/org/codehaus/groovy/transform/CanonicalComponentsTransformTest.groovy
