reportsDir = "build/geb"
driver = "firefox"