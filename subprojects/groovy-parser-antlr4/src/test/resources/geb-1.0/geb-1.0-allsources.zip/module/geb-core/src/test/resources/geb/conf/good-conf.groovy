a = 1

environments {
    e1 {
        a = 2
    }
    e2 {
        a = 3
    }
}