report {
  enabled true
  logFileSuffix System.getProperty("org.gradle.test.worker")
  issueUrlPrefix "http://issues.spockframework.org/detail?id="
  issueNamePrefix "SPOCK-"
}