report {
  enabled true
  logFileSuffix System.getProperty("org.gradle.test.worker")
}