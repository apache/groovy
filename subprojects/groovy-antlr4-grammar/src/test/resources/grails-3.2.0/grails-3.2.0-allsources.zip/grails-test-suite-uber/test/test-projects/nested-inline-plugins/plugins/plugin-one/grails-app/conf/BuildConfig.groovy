grails.plugin.location.'plugin-two'="../plugin-two"
