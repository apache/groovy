package org.grails.domain;

class OneToManyTest2 {

    int id;
    int version;
    RelationshipsTest other; // many-to-one relationship

}