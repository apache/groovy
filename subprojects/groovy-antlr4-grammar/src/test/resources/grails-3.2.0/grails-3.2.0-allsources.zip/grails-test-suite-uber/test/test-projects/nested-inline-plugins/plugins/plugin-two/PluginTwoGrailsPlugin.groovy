class PluginTwoGrailsPlugin {}
