package org.grails.plugins;
class ClassEditorGrailsPlugin {

    def version = 1.1

    def withSpring() {}

    def withApplicationContext(ctx) {}
}
