package org.grails.domain

class ManyToManyTest {
    Long id
    Long version
}