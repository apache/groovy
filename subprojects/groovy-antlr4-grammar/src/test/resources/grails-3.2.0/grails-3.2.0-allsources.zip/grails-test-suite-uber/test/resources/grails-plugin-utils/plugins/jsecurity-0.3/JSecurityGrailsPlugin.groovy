class JsecurityGrailsPlugin {
    def version = "0.3"
}