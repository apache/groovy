package org.grails.commons.cfg

a = 1