package foo

class FooController {}
