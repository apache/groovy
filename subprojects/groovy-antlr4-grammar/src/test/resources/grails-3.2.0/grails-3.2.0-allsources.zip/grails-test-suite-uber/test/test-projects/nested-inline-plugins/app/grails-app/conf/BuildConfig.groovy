grails.plugin.location.'plugin-one'="../plugins/plugin-one"
grails.plugin.location.dummy="${System.getProperty('java.io.tmpdir')}/.grails/test/dummy"
