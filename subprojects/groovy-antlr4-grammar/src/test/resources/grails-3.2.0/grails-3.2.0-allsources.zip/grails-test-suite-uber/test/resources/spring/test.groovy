beans {
	foo String, "hello"
}