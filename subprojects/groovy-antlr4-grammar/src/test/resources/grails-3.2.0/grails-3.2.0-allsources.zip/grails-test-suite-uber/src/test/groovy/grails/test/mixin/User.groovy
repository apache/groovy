package grails.test.mixin

import grails.persistence.Entity

@Entity
class User {
    String username
    String password
}
