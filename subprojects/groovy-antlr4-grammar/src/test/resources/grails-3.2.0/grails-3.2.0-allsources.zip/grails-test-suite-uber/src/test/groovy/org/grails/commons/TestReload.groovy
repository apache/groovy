package org.grails.commons

class TestReload {
    String hello = "goodbye"
}
