package org.grails.commons.cfg

b = 1