package org.grails.web.servlet.mvc.alpha

class AnotherNamespacedController {

    def demo() {
        render 'Rendered by the primary AnotherNamespaced Controller'
    }
}
