package grails.test.mixin

import grails.web.Controller

@Controller
class FirstController {
    def index() {}
}
