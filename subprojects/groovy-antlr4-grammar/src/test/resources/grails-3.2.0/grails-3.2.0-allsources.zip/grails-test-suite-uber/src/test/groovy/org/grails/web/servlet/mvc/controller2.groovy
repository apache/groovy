package org.grails.web.servlet.mvc

class SimpleController {
    Closure test = {
        return null;
    }
}
