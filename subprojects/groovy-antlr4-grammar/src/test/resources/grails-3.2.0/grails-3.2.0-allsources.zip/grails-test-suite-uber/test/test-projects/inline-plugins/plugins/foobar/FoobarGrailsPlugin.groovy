class FoobarGrailsPlugin {}
