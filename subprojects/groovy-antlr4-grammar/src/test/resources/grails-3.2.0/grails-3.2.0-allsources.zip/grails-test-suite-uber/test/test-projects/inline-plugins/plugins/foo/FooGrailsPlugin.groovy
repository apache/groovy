class FooGrailsPlugin {}
