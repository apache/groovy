package org.grails.domain;

class UniOneToManyTest {

    int id;
    int version;
}