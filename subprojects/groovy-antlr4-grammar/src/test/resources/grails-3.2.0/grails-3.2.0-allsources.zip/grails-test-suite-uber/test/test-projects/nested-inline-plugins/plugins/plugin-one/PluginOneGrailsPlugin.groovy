class PluginOneGrailsPlugin {

    

}