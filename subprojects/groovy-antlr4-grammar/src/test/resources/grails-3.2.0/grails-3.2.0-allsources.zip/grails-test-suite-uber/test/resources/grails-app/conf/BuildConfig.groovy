grails.project.work.dir = "preInitWork"
grails.project.class.dir = "build/classes"
grails.project.test.class.dir = "build/test-classes"
grails.war.destFile = 'foo.war'
