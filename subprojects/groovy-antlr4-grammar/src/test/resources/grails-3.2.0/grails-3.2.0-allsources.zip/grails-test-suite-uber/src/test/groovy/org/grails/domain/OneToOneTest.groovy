package org.grails.domain

class OneToOneTest {

    Long id
    Long version

    RelationshipsTest other
}
