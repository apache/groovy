package org.grails.domain;

class Test2 {
    Long id
    Long version
    String firstName
    String lastName
    Date age
}
