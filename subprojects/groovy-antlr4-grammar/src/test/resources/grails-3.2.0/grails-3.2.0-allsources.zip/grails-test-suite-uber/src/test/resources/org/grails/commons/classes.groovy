class TestClass1 {
}

class TestClass2 {
    static boolean available = true
}