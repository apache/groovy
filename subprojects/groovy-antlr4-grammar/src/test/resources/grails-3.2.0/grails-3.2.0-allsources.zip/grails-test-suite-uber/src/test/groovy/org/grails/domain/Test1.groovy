package org.grails.domain

class Test1 {
    Long id
    Long version
    String firstName
}
