grails.plugin.location.foo="../plugins/foo"
grails.plugin.location.foobar="../plugins/foobar"
