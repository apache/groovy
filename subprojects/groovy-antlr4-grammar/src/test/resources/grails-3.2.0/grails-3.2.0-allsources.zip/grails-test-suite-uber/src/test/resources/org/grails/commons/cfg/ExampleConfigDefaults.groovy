package org.grails.commons.cfg

a = 2