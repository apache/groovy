package org.grails.validation
constraints = {
    name(blank:false)
}