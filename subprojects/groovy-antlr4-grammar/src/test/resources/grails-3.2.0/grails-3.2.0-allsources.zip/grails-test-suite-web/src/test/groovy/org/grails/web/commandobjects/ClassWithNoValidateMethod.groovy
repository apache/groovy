package org.grails.web.commandobjects

class ClassWithNoValidateMethod {
    int validationCounter = 0
}
