package org.grails.web.commandobjects

class NonValidateableCommand {
    String name
}
